Mediterranean itlififFff'J) countries about 6,000 years ago. HY IB NOREL BAT REA TEIN. We A.
80.D AFL. ZEAE TE ROR IS A, HURST HT RB TE RRA Pe, RA, te
WTF, (EULER BBE ERIN. HG De
81.B 41532 AFG. HLH In ancient Greece, for example, anyone who cut down an olive tree was heavily punished.
Wut Be
82.D VENEER. HR LC SR 7 VCE, HI. De.
Ae: PARE.
D
While many young people were enjoying the summer vacation, Zach Bonner was working his hardest. Zach
started walking from Valrico, Florida, his hometown, on Christmas, 2009. He reached Los Angeles nine months
later in September, 2010. He covered a total of 2,478 miles and -raised $120,000 for kids in need, Along the way,
Zach attended schoo! online. His mother, brother and sister took turns to walk or drive together with him.
Although he is very young, Zach has a long history of helping others. When a terrible storm hit town in 2004,
Zach, when six, pulled a wagon (/)-4{é4) through his community and collected food for people in need.
He has raised $400,000 for his Little Red Wagon Foundation since then. It gives money to projects which help
homeless children. In 2007, Zach began walking to support a children’s charity (2441142) in Tampa, Florida. He
finished his journey 23 days later, 280 miles away in Tallahassee. Then in the summer of 2009, he trekked about
670 miles from Atlanta to Washington, D.C., in just two months.
“As long as there are homeless kids, I will never stop walking for them.”Zach says.
83. What did Zach do during the summer vacation in 2010?
A. He stayed at home to look after his family.
B. He travelled to his hometown with his family.
CC. He joined in a school activity with other kids.
D. He walked to collect money for kids in need.
84. We can leam from Paragraph 2 that Zach
A. began to help people at a very early age B. made money to pay for his education
C. enjoyed playing around in his community _D. worked very hard for his family
85. At what age did Zach start walking to support a Tampa children’s charity?
A. Atsix. . B.Atnine. C. At eleven. D. At twelve.