a 2 S it off for a few days from the pressures of modern day living as
completely as you can in Bruges. Its beauty and peace are
perfectly preserved in this medieval town in Europe.
¢ Two days from only £599 per person (£100 for an extra
day)
e Price Includes: meals in local restaurants; return flights
or railway
‘) When we take the tour to Georgia, we can__.
A. enjoy the beautiful trees in the countryside
B. visit some famous tourist sites in big cities
C. taste the peace of medieval town in Europe
D. taste the local foods in the restaurants without extra fee
‘2 What is special about the tour to New England?
A. It contains a specialized tour guide service.
B. It boasts a beautiful scenery of the mountains.
C. It promises free return flights to any places.
D. It unfolds the amazing history of whole America.
°3) What do the three tours have in common?
A. Each tour provides hotel accommodation.
B. Superb travel experiences are guaranteed.
C. No discounts are offered.
D. Only flight transport is provided.
4 stunning /'stanin/ adj, 43985,
2 invaluable /in'vaeljuabl/ adj. RRR
3 nestle /'nesl/ v. Arkh, SAE
4 accommodation /a,koma'deifn/ n. fERb; (ETS
5 carpet /'ka:pit/ vi eg
6 stand apart from BH; ize
7 switch off FS; BL
18
QRS (XAF2) SAF SRE, QALMME. HS SER