Therefore
(ai,2,4:41),(ais1,4j,4)) € 8 > (aj,ai,2) ES
(ai,z,4)), (4j,4j41,41) € S = (Z,4j,4541),
so (aj,z,a;41) ¢ S. The case j = i+ 1 is ruled out by
(ai, 2, 4141), (4i41,4142,41) € S > (2, 4i41,4142) ES
and the case j = i—1 is similar.
Finally, we put g(z) in (g(dn).+%) if i= n, and
(g(ai),@(ais1)) otherwise; an analysis similar to that
above shows that g has the desired property.
A-5 (due to Lenny Ng) For | <n < p—1, p divides (?) and
ne)
panel
(ye!
n
(modp),
where the congruence x = y (mod p) means that x—y is
a rational number whose numerator, in reduced form, is
divisible by p. Hence it suffices to show that
ye
tinguish two cases based on p (mod6). First s
r+ 1, so that k = 4r. Then
pose p
a aye
iar
Le (Lt
es n 6r+1—n
=0(modp).
y 2
© nee (PR)
since p= 6r+1.
Now suppose p = 6r-+5, so that k= 4r-+3. A simi
argument gives
483 (yy
n
nt
wep 4
> (+ acs)
noted
=0(modp).
A~6 We first consider the case c < 1/4; we shall show in this
case f must be constant. The relation
P(x) = f(P +e) = f((-xP +0) = F(-
proves that
roots of x7 +¢
an even function, Let r) < rz be the
x, both of which are real. If x > r2,
define xo =x and xq1 = VIn—€ for each positive in-
teger x, By induction on 1, 2 <Xn41 <p for all n, so
the sequence {x,} tends to a limit L which is a root of
2° +c =xnot less than r. Of course this means L =r.
Since f(x) = f(y) for all n and x» > r, we conclude
(x) = f(r), 80 fF is constant on x > rp.
If ry <x <r and xy is defined as before, then by in-
duction, x» <.n41 <7. Note that the sequence can be
defined because ry > c; the latter follows by noting that
the polynomial x7 —x +c is positive atx = c and has
its minimum at 1/2 > c, so both roots are greater than
c. In any case, we deduce that (x) is also constant on
nSxsn.
Finally, suppose x < ri. Now define xy = x.xn41 =
x2 +e. Given that x) < ry, we have xn41 >%,. Thus if
we had x, <rj forall n, by the same argument as in the
first case we deduce x > ry and so f(x) = f(r). Actu-
ally, this doesn’t happen; eventually we have x, > r1, in
which case f(x) = f(x») = f(r) by what we have al-
ready shown, We conclude that f is a constant function.
(Thanks to Marshall Buck for catching an inaccuracy in
a previous version of this solution.)
Now suppose c > 1/4. Then the sequence x, defined
by ao = 0 and 4) =a} +c is strictly increasing and
has no limit point. Thus if we define f on [xo,.x1] as any
continuous function with equal values on the endpoints,
and extend the definition from [x,.2%n41) tO [X41 .4n4/
by the relation f(x) = f(x? +c), and extend the defini-
tion further to x <0 by the relation f(x) = f(—x), the
resulting function has the desired property. Moreover,
any function with that property clearly has this form,
B-I Let {n] denote the set {1,2,...,n}, and let fy, denote
the number of minimal selfish subsets of [n]. Then the
number of minimal selfish subsets of {n] not containing
nis equal to f,-1. On the other hand, for any mini-
mal selfish subset of [n] containing n, by subtracting 1
from each element, and then taking away the element
n— | from the set, we obtain a minimal selfish subset
of {n—2] (since 1 and n cannot both occur in a selfish
set). Conversely, any minimal selfish subset of [n — 2]
gives rise to a minimal selfish subset of [n] containing
nby the inverse procedure. Hence the number of mini-
mai selfish subsets of [n] containing n is f,-2. Thus we
obtain fy = fn + fn-2- Since fi = fo = 1, we have
Jn = Fy, Where F, denotes the nth term of the Fibon:
sequence.
B-2 By estimating the area under the graph of In. using up-
per and lower rectangles of width 2, we get
ant
[ Inxdx < 2(In(3) +-++-+In(2n—1))
f
ant
< I Inxdx.
Since f Inxdx = xInx—x-+C, we have, upon exponen-