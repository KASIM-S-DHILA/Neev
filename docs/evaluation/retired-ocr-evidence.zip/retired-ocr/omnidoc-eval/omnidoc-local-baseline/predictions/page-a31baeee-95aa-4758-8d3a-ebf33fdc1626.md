Tied Results
Unless the tie can be broken by a call-on tre
. another length is run
and another roll is made, but you must obey the Let It Ride rules. Test
another ability or skill. We recommend making F
orte tests for long
distance chases.
Linked Tests for Extended Chases
Ifa player wants to underta
an extended, multi-} . the
GM should outline the number of tests required to p:
ates
Winning
rains +1D to the next test. In an extended chase, two consecutive
wins puts the pursued out of reach of the chaser: