Let's Review
® Look, listen and choose. Jj
Name: Nancy 9
Favourite things: animals
and plants
Good at: planting flowers
Wants to be: a farmer
Name: Sam @
Favourite things: cars
Good at: driving bumper cars
Wants to be: a driver
8
This is Ann. She likes delicious food.
he wants to be a cook in the future.
She is good at cooking.
Name: Ann
Favourite things: delicious food
Good at: cooking
Wants to be: a cook
Name:
Favourite things:
Good at:
Wants to be: