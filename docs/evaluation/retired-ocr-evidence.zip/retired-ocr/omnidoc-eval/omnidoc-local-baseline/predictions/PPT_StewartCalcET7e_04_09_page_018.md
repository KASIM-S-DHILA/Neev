BR pic 6 — Solution
Note that v(0) = C. But we are given that v(0) = -6, so
C=-6 and
cont'd
V(t) = 3t2 + 4t-6
Since v(t) = s'(#), sis the antiderivative of v:
s() = 35 +45-6t+D=f+20—-6t+ D
This gives s(0) = D. We are given that s(0) = 9,so D=9
and the required position function is
s(t) = 8 + 2t-6t+9