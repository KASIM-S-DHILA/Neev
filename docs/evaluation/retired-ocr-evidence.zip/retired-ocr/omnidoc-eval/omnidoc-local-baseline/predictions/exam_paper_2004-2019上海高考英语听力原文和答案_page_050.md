. M: When will Flight BA981 from New: York arrive?
W; It was scheduled to arrive at 1:00 p.m., but it will be delayed for an hour and a half.
Q: When will the plane arrive?
M; I'd like to have a look at that blue sweater in the window, please.
W: Yes, what size do you take?
Q: Where does the conversation most probably take place?
W: Good evening, sir, would you like to see the menu?
M, No, thank you. I’ve already known what I want to order.
Q: What’s the possible relationship between the two speakers?
M; Hotel rooms along the beach must be very expensive.
W: Not now, It’s out of the season and they are awfully cheap.
Q: What/does the woman say-about the hotel rooms now?
5.W
M:
: John, how did your maths exam go?
: [thought I might have failed but in fact I became the top 10% in the class.
Q: What can we learn about the man from the conversation?
1 What did you thing of yesterday’s film?
M; Well, I left when the film was only half way through.
Q: What was the film like according to the man?
W: Come on, what are we waiting for?
M; Sorry, Madam, I can’t start until you put on your seat belt.
Q: What does the man mean?
M; Congratulations, Mary! I heard you won the first prize at the speech contest.
W: There must be another Mary, I wasn’t there.
Q: What does the woman mean?
| M; Honey, do you realize you had an appointment with the dentist an hour ago?
W: did?
Q;, What?s the woman’s reaction to the man’s remark?
10. W: Oh, that’s too'bad. It?s out of order again.
M; Sorry, Madam, but you have to walk upstairs today. 1
Q: What are the speakers probably, talking about? (is) ot 9!
Part B_ Passages
Directions; In Part.B, you will hear two short passages and you will be askedithree questions om each
of the passages. The passages will be read twice but the questions will be spoken only/once. When you
hear a question read the four possible answers on your. paper and decide which one rdould be.the best
‘answer to the question you have heard.
Questions 11 through 13 are based on the following passage, i :
Last month, I went to Manchester for a work meeting, I booked:into a very:nice hotel {6r two
nights and T was very happy with it. My room was beautiful and the restaurant served very good! food.
In fact my dinner there that fist night was delicious, but when T came back from my meeting’n the
second day, I found my room empty. All my things hed disappeared, T checked that T.was in the’ right
oom and then I rushed down to the reception. I was,really worried because T thought I’d been robbed.
When I got to the reception, I said my room was empty. All my things: had been stolen but the
NREXH HAREPSABR #50 KG S2 TD