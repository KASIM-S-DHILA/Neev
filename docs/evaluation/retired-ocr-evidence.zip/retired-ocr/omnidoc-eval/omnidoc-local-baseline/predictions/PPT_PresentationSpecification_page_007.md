IMPORTANT DATES
@ You should:
e@By Jan 24, 2016;
Form groups with 4 students; and
a Determine your presentation topic; and
e@By Jan 31, 2016;
Submit the Group Presentation Topic and Desc;
a Don’t miss the due dates!!!
o We suggest you taking action as early as
possible;
tC ENGG1000 Presentation Specification 5/21/2025