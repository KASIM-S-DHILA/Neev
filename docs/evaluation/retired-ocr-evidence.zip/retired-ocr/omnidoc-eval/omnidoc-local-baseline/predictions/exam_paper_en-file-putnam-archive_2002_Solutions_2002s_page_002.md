A-5 It suffices to prove that for any relatively prime positive
integers 1,s, there exists an integer n with a, =r and
y.1 = 5. We prove this by induction on r+s, the case
r-+s=2 following from the fact that ap = a; = 1. Given
rand s not both I with ged(r,s) = 1, we must have r
s. If r>s, then by the induction hypothesis we have
iy = 1 —8 and dy 1 = 5 for some n; then ayy 2 =r and
d2y43=5. Ir <5, then we have dy = rand dy) =s—r
for some n; then dq4.1 = rand dyy42 =.
Note: a related problem is as follows. Starting with the
sequence
o1
V0"
repeat the following operation: insert between each pair
4 and § the pair #5. Prove that each positive rational
number eventually appears.
Observe that by induction, if ¢ and § are consecutive
terms in the sequence, then be —ad = 1. The same holds
for consecutive terms of the n-th Farey sequence, the
sequence of rational numbers in (0, 1] with denominator
(in lowest terms) at most n.
A-6 The sum converges for b = 2 and diverges for b > 3. We
first consider b > 3. Suppose the sum converges; then
the fact that f(n) =nf(d) whenever b?-! <n < b4—1
yields
ey MY
However, by comparing the integral of 1/x with a Rie-
mann sum, we see that
way in dx
ts a
nop SX
= log(b“) — log(b’') = log,
where log denotes the natural logarithm. Thus (1) yields
YS > (ogy) ¥ 4.
Are Are)
a contradiction since logh > | for b > 3. Therefore the
sum diverges.
For b =2, we have a slightly different identity because
(2) #2f(2). Instead, for any positive integer i, we
have
1 1
Lama ttatet
Again comparing an integral to a Riemann sum, we see
that for d > 3,
1
Sg tlog? <0.125+07.<1
Put c= { +log2 and L = 1+ 4+ giz. Then we can
Fin <E forall i > 2 by induction on i.
The case i = 2 is clear. For the induction, note that by
Q,
as desired. We conclude that P7714; converges to a
limit less than or equal to L.
Note: the above argument proves that the sum for b = 2
is at most L < 2.417. One can also obtain a lower
bound by the same technique, namely 1+ 5+ giz
with c/ = log2. This bound exceeds 2.043. (By con-
trast, summing the first 100000 terms of the series only
yields a lower bound of 1.906.) Repeating the same ar-
‘guments with d > 4 as the cutoff yields the upper bound
2.185 and the lower bound 2.079.
The probability is 1/99. In fact, we show by induction
on 7 that after n shots, the probability of having made
any number of shots from 1 to n—1 is equal to 1/(n —
1). This is evident for n = 2. Given the result for n,
we see that the probability of making i shots after n+ 1
attempts is
I) +(n-i)
n(n —1)
as claimed.
B-2 (Note: the problem statement assumes that all polyhe-
dra are connected and that no two edges share more than
one face, so we will do likewise. In particular, these are
true for all convex polyhedra.) We show that in fact
the first player can win on the third move. Suppose the
polyhedron has a face A with at least four edges. If the
first player plays there first, after the second player's
first move there will be three consecutive faces B,C, D
adjacent to A which are all unoccupied. The first player
wins by playing in C; after the second player's second