System of linear equations
A collection of one or more equations involving the same variables.
Example:
2x, + 3x2 +4x3=5
5x3 + 6X4 =7
Ox, + 0x2 + 5x3 + 6X4 =7
Hence it is a system of equations involving the variables x4, x2, x3, X4.
The system of linear equations
can be rewritten as