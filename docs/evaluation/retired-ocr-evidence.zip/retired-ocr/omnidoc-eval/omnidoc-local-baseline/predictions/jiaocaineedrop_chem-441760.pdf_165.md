LibreTexts”
[Boranic Puno. Grogs 206.24 p{GYOnale Functional Groups 2016 pa
FUNCTIONAL GROUPS IN ORGANIC CHEMISTRY
Functional groups are the characteristic groups in organic molecules that give them thei reactity. nthe formulae below, Represents the rest ofthe molecule and represents any halogen atom,
ALKANE ALKENE ALRYNE ADE muonuiane ALCL, ALBEE xeToNe —careonCACO pc AOR
_, Pe NE AMIDE RITE NITRILE
8ee8e
NITROSO WINE MDE ‘IDE Cue SOCMIATE ATOCOWPOWND THO SULFIDE UUSULFIDE
v
ey a se
ee &) & ) Se) Cs) 3
SUFOXDE _SULFONE _—_SULFINICACIO._SULFONICACIO. SULFOWATEESTER THIOCYANATE ISOTHIOCYANATE——THIAL THIOKETONE —_PHOSPHINE
Si, SS SM SN Se, Ieee a pent
© ‘© Andy Brunning/Compound Interest 2020 - www.compoundchem.com | Twitter: @compoundchem | FE: www facebook com/compoundchem SOC)
This grophic ls shared under a Creative Commons Attebution-NonCommercia-NoDerivaives 4, OUcence,
Figure 5.2.1: Functional groups in organic chemistry. (CC BY-NC-ND, CompoundChem.com).
‘This page titled 5.2: Families of Organic Molecules - Functional Groups is shared under a CC BY-NC-SA 3.0 license and was authored, remixed,
and/or curated by Lisa Sharpe F
44431