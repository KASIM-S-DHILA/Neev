Part 4 Faia
Ana Johnson
Ana Johnson is a 13-year-old swimmer who lives in Melbourne in
Australia. Her dream is to swim for Australia in the next Olympics.
She swims in both long and short races and she has already
come first in many important competitions.
Example:
0 Ana’s home is in Melbourne.
ARight B Wrong C Doesn't say
21 Ana hopes she will become an Olympic swimmer.
A Right B Wrong C Doesn't say
22 Ana knows that she is better at short races than long ones.
A Right B Wrong C Doesn't say
Part 5 #0 aN
Not long after he returned home, he started Cirque with (30) ....
friend, Daniel Gauthier. During the 1990s, Cirque grew quickly. It
now does shows (31) .... over the world and the number of people
working for it has grown from 73 to (32) .... than 3,500.
30Atheir Bhis  Cits
31Asome Ball C enough
32Amore Bmuch C many
Part 5 #0 zy
A famous circus
The circus, Cirque du Soleil, began (0) .... Montreal, Canada.
It was started (28) .... the Canadian Guy Laliberté in 1984.
When he left college, Laliberté travelled around Europe and
earned
money (29) .... music in the streets.
Example:
oO Ain Bat Cto Answer: A
28 Afrom Bby Cof
29 Aplayed Bplays C playing
KETHIZ ERE HA
BR RE
BRA AA LAG a
BHA
SHANA
PIR A: BR HE”
HBEEERA: chulianyi@xueersi.com
QQ: 87124697