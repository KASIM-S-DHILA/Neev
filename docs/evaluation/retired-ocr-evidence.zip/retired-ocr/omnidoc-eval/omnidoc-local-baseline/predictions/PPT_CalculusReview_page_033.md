Integral Calculus
(n+l)
[ax"ax =a +C
n+l
2
[ax dx =a—+C
2
3
Jarar=a5+C