7.6 For Reference:
Second- and Third-Order Determinants
Cramer’s Rule for Linear Systems of Three Equations
Ay,X, + 4X, +4,,X, =),
5
©) Ay, X, + AyyX, + A,X, =b,
Ax X, + AxXy + Ag.X5 = b,
is
D D D
(6) ma y= = (D #0)
with the determinant D of the system given by (4) and
b, Ay, a3 Ay b, dh, Ay, M5 b,
D, =b, Any yg), Dy =| b, Ays|, D3 =|Ay, Ag b,}.
b, As, As, ay, b, As, As, As, b,
Note that D,, D, D3 are obtained by replacing Columns 1, 2,
3, respectively, by the column of the right sides of (5).
Section 7.6 p90 Advanced Engineering Mathematics, 10/e by Edwin Kreyszig
Copyright 2011 by John Wiley & Sons. All rights reserved.