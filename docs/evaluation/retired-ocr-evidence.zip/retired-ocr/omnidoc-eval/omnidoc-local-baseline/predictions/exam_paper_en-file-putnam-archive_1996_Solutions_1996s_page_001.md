Solutions to the 57th William Lowell Putnam Mathematical Competition
Saturday, December 7, 1996
Manjul Bhargava and Kiran Kedlaya
A-I If x and y are the sides of wo squares with combined
area 1, then x? + Suppose without loss of gen-
erality that x > y. Then the shorter side of a rectangle
containing both squares without overlap must be at least
x, and the longer side must be at least x+y. Hence the
desired value of A is the maximum of x(x+y).
To find this maximum, we let x = cos ,)
6 € (0, 2/4). Then we are to maximize
sin @ with
cos? @ + sin @cos @ = A +-cos20 + sin20)
v2
1
= 3 +S e0s(20 2/4)
14v2
with equality for @ = 7/8. Hence this value is the de-
sired value of A.
A-2 Let 01 and Oz be the centers of C; and Ca, respectively.
(We are assuming C; has radius 1 and C) has radius
3.) Then the desired locus is an annulus centered at the
midpoint of O10, with inner radius | and outer radius
2.
For a fixed point Q on Cp, the locus of the midpoints of
the segments PQ for P lying on C; is the image of C,
under a homothety centered at Q of radius 1/2, which
is a circle of radius 1/2. As Q varies, the center of this
smalller circle traces out a circle C3 of radius 3/2 (again
by homothety). By considering the two positions of @
on the line of centers of the circles, one sees that C3 is
centered at the midpoint of 0; 02, and the loci
clearly the specified annulus.
A-3 The claim is false. There are ($) = 20 ways to choose
have each student choose a different
Then each pair of courses is chosen by
4 students (corresponding to the four ways to complete
this pair to a set of 3 courses) and is not chosen by 4
students (corresponding to the 3-element subsets of the
remaining 4 course
Note: Assuming that no two students choose the same
courses, the above counterexample is unique (up to per-
muting students). This may be seen as follows: Given a
group of students, suppose that for any pair of courses
(among the six) there are at most 4 students taking both,
and at most 4 taking neither. Then there are at most
120 = (4 +4)(5) pairs (s,p), where s is a student, and
isa set of two courses of which s is taking either both
or none. On the other hand, if a student s is taking k
courses, then he/she occurs in f(k) = (8) + (5%) such
pairs (s,p). As f(k) is minimized for k = 3, it follows
that every student occurs in at least 6 = (3) + (3) such
pairs (s, p). Hence there can be at most 120/6 = 20 stu-
dents, with equality only if each student takes 3 courses,
and for each set of two courses, there are exactly 4 stu-
dents who take both and exactly 4 who take neither.
Since there are only 4 ways to complete a given pair
of courses to a set of 3, and only 4 ways to choose 3
courses not containing the given pair, the only way for
there to be 20 students (under our hypotheses) is if all
sets of 3 courses are in fact taken. This is the desired
conch
However, Robin Chapman has pointed out that the so-
lution is not unique in the problem as stated, because a
given selection of courses may be made by more than
one student, One alternate solution is to identify the 6
courses with pairs of antipodal vertices of an icosahe-
dron, and have each student pick a different face and
choose the three vertices touching that face. In this ex-
ample, each of 10 selections is made by a pair of stu-
dents.
A-4 In fact, we will show that such a function g exists with
the property that (a,b,c) € $ if and only if g(d) <
g(e) < g(f) for some cyclic permutation (d,e, f) of
(a,b,c). We proceed by induction on the number of
elements in A. If A = {a,b,c} and (a,b,c) € S, then
choose g with g(a) < g(b) < g(c), otherwise choose g
with g(a) > g(b) > g(c).
Now let z be an element of A and B
4)... 4y be the elements of B labeled such that g(a1) <
(a2) <--> <g(ay). We claim that there exists a unique
ie {1,....n} such that (aj,z,q;41) € S, where hereafter
Gnsk = Ak.
—{z}. Let
We show existence first. Suppose no such exists; then
for all i,k € {1,....n}, we have (ais4,2.4i) ¢ 8. This
holds by property 1 for k = 1 and by induction on & in
general, noting that
disk) (Aisk,2,41) € S
> (disks Giskcts2)s(Zdisdign) €S
=> (dizks1,2,ai) €S.
(Gisket
Applying this when k = n, we get (a;-1.z,a;) € , con-
tradicting the fact that (a;,z,a)-) € S. Hence existence
follows,
Now we show uniqueness. Suppose (a),z,4)1) €
S; then for any j A i- ii +1, we have
(ai,a1,4)),(aj,4}41,4)) €S by the assumption on G.