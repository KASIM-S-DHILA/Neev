B-5 The functions f(x)
W1,.-+,Wn be the projections of ¢1,...,én. If the desired
condition is not achieved, we can choose i,j such that
1
<= (|w
n
st Lwal?) < by
By precomposing with a suitable rotation that fixes
efor h 4 i,j, we can vary |v], |;| without varying
|wil? + fw)|? or fiv,| for h A i,j. We can thus choose
such a rotation to force one of |w;|?, {w;|? to become
equal to 4(\w|?+-+++|wn|?). Repeating at most n— 1
times gives the desired configuration.
B-4 We use the identity given by Taylor's theorem:
ex) 419 (x)
A(xt+y)
In this expression, h(x)/i! is a polynomial in x with
integer coefficients, so its value at an integer x is an
integer.
For
0,...,p—1, we deduce that
A(x+p) =h(x) + ph'(x) (mod p*).
(This can also be deduced more directly using the bino-
mial theorem.) Since we assumed h(x) and Moe p)
are distinct modulo p?, we conclude that /(x)
(mod p). Since i! is a polynomial with integer ek
ficients, we have I(x) = h’(x-+mp) (mod p) for any
integer m, and so h'(x) 0 (mod p) for all integers x.
Now forx=0,...,p?—1and y=,
*) = h(x) + p?yh'(x) (mod p*).
Thus h(x),A(x+p?),...,Ai(x+(p—1)p?) run overall of
the residue classes modulo p? congruent to h(x) mod-
ulo p?. Since the h(x) themselves cover all the residue
classes modulo p®, this proves that h(0),...,(p> — 1)
are distinct modulo p°.
p~1,we write
het
Remark: More generally, the same proof shows that
for any integers d,e > 1, h permutes the residue classes
modulo p* if and only if it permutes the residue classes
modulo p*. The argument used in the proof is related
toa general result in number theory known as Hensel’s
lemma.
x-+mand f(x) =—x-+n for any
integer 1 clearly satisfy the condition of the problem;
wwe claim that these are the only possible f
Let q = a/b be any rational number with ged(a,b) =
and b > 0, For n any positive integer, we have
= inp (%**) ~ nbs (5)
is an integer by the property of f. Since f is differ-
entiable at a/b, the left hand side has a limit, It fol-
lows that for sufficiently large n, both sides must be
plant
equal to some integer c = f"($): f\ ae =SfG)+E-
Now c cannot be 0, since otherwise f(t!) = f(¢) for
sufficiently large n has denominator b rather than bn.
Similarly, |c| cannot be greater than 1: otherwise if we
take n = k\c| for k a sufficiently large positive integer,
then f(¢) +; has denominator bk, contradicting the
fact that (+) has denominator bn. It follows that
c= fj) =21
Thus the derivative of f at any rational number is +1
jwously differentiable, we conclude that
for all real x or f'(x) = —1 for all real x. Since
st be an integer (a rational number with denom-
inator 1), f(x) =x-++n or f(x) = —x-+n for some integer
n
Remark: After showing that /"(q) is an integer for each
4g, one can instead argue that /” is a continuous function
from the rationals to the integers, so must be constant.
One can then write f(x) = ax-+b and check that b € Z
by evaluation at a = 0, and that a= +1 by evaluation at
x= Ifa
B-6 Inall solutions, let Fj, be the number of k-limited per-
mutations of {1,...,1}
First solution: (by Jacob Tsimerman) Note that any
permutation is k-limited if and only if its inverse is k-
limited. Consequently, the number of k-limited per
mutations of {1,....n} is the same as the number of
k-limited involutions (permutations equal to their in-
verses) of {1,....n}.
We use the following fact several times: the number of
involutions of {1,....7} is odd if n = 0, 1 and even oth-
erwise. This follows from the fact that non-involutions
come in pairs, so the number of involutions has the same
parity as the number of permutations, namely n!.
For n < k-+ 1, all involutions are k-limited. By the pre-
vious paragraph, F;,4 is odd for n = 0,1 and even for
n= kth
For n> k+1, group the k-limited involutions into
classes based on their actions on k+2,...,2. Note
that for C a class and o € C, the set of elements of
A= {I,...,k-+1} which map into A under o depends
only on C, not on @. Call this set $(C); then the size of
Cis exactly the number of involutions of $(C). Conse-
quently, |C] is even unless S(C) has at most one element.
However, the element I cannot map out of A because we
are looking at k-limited involutions. Hence if $(C) has
one element and & € C, we must have (1) = 1. Since
G is k-limited and (2) cannot belong to A, we must
have 6(2) =k +2. By induction, for = 3,...,k-+1,
we must have o(i) = k-+i.
If n <2k-+1, this shows that no class C of odd cardi-
nality can exist, so Fx must be even. If n> 2k-+1,
the classes of odd cardinality are in bijection with k-
limited involutions of {2k-+2,....n}, So Fy has the
same parity as F241... By induction on n, we deduce
the desired result.