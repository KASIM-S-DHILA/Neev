SUMMARY OF CHAPTER 7
Linear Algebra: Matrices, Vectors,
(continued 3) Determinants. Linear Systems
The transpose AT of a matrix A = [a] is AT = [a,]; rows
become columns and conversely (Sec. 7.2). Here, A need not
be square. If it is and A= A', then A is called symmetric; if
A=—A, it is called skew-symmetric.
For a product, (AB)' = B'A! (Sec. 7.2).
A main application of matrices concerns linear systems of
equations
(2) Ax=b (Sec. 7.3)
(m equations in n unknowns X;, ... , x,; A and b given).
Section 7.Summary p142 Advanced Engineering Mathematics, 10/e by Edwin Kreyszig
Copyright 2011 by John Wiley & Sons. All rights reserved.