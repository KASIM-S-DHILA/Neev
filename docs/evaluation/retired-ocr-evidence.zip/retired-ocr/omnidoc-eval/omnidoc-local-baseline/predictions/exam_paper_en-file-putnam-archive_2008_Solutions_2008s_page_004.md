B-2 We claim that F,(x)
B-3 The largest possible rad
(by elementary algebra, or Cramer’s rule), so the center
of the circle is rational. This proves the desired result.
Remark: The above solution is deliberately more ver-
bose than is really necessary. A shorter way to say t
is that any two distinct rational points determine a ra-
tional line (a line of the form ax +by +e = 0 with a,b,c
rational), while any two nonparallel rational lines inter-
sect at a rational point. A similar statement holds with
the rational numbers replaced by any field.
Remark: A more explicit argument is to show that
the equation of the circle through the rational points.
(xisyi); (x2,¥2) (3,93) is
pty x yt
XQ+Y2 ¥2 Yr
qty as ys
vtyox y
1
O=det t
1
which has the form a(x? + y?) +dx+ey+ f =0
for a.de,f rational. The center of this circle is
(-d/(2a), -e/(2a)), which is again a rational point.
Inx —ay)x"/n!, where ay
YjLy 1/k. Indeed, temporarily write G(x) = (Inx —
ay)x"/n} for x > 0 and n> 1; then limy-s0 Gn(x) = 0
and Gi,(x) = (Inx— ay +1/n)x"!/(n=1)! = Gy1(x),
and the claim follows by the Fundamental Theorem of
Calculus and induction on n.
Given the claim, we have F,(1) = —ay/n! and so we
need to evaluate —lim, 2. 4. But since the function
1 /xis strictly decreasing for x’positive, Pf 1/k = dy —
1 is bounded below by f;"dx/x = Inn —In2 and above
by f{'dx/x = Inn. It follows that lim, .. 2 = 1, and
the desired limit is —1.
22. It will be convenient
to solve the problem for a hypercube of side length 2
instead, in which case we are trying to show that the
largest radius is V2.
Choose coordinates so that the interior of the hypercube
is the set H = [—1,1]* in R‘. Let C be a circle centered
at the point P. Then C is contained both in H and its
reflection across P; these intersect in a rectangular par-
alellepiped each of whose pairs of opposite faces are at
most 2 unit apart. Consequently, if we translate C so
that its center moves to the point O = (0,0,0,0) at the
center of H, then it remains entirely inside H.
‘This means that the answer we seek equals the largest
possible radius of a circle C contained in H and
centered at O. Let vy = (Vtiy.-..¥14) and v2 =
(v2 14) be two points on C lying on radii perpen-
dicular to each other. Then the points of the circle can
be expressed as vj cos +v2 sin for 0 < @ < 2m. Then
C lies in H if and only if for each i, we have
|viscosO +vx;sin8] <1 (0< @ < 2a).
In geometric terms, the vector (vj;,v2)) in R? has
dot product at most 1 with every unit vector. Since
4
this holds for the unit vector in the same direction as
(vuj,v2i), We must have
vitvist
4)
Conversely, if this holds, then the Cauchy-Schwarz in-
equality and the above analysis imply that C lies in H.
If r is the radius of C, then
2r
sor < V2. Since this is
(1,1,0,0) and (0,0,1,1),
Remark: One may similarly ask for the radius of the
largest k-dimensional ball inside an n-dimensional unit
hypercube; the given problem is the case (nk) = (4,2).
Daniel Kane gives the following argument to show that
the maximum radius in this case is }\/. (Thanks for
Noam Elkies for passing this along.)
hieved by the circle through
the desired maximum.
We again scale up by a factor of 2, so that we are trying
to show that the maximum radius r of a k-dimensional
ball contained in the hypercube (1, 1]" is \/2. Again,
there is no loss of generality in centering the ball at the
origin. Let T: R‘ + R" be a similitude carrying the
unit ball to this embedded k-ball. Then there exists a
vector v; € R* such that for e1,...,¢n the standard basis
of R", x-v; = T(x) -¢; for all x € RE. The condition of
the problem is equivalent to requiring |v;| <1 for all i,
while the radius r of the embedded ball is determined
by the fact that for all x € R',
Pex) = 76): TO) = Ew
a
Let M be the matrix with columns y),....vg;_ then
MM! = ?;, for k; the k xk identity matrix. We then
have
kr? =Trace(r’k) = Trace(MM" )
= Trace(M™M) = ¥ |v?
a
Sa,
yielding the upper bound r < \/7
To show that this bound is optimal, it is enough to show
that one can find an orthogonal projection of R" onto R*
so that the projections of the ¢; all have the same norm
(one can then rescale to get the desired configuration
of V,..-,¥_). We construct such a configuration by a
“smoothing” argument. Startw with any projection. Let