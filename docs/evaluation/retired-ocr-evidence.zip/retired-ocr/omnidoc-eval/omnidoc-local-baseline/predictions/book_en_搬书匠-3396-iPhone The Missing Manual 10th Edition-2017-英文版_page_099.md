ee0oe Verizon PF WEPM = 7 5 95% KEDY J eocoo Verizon F = WHZPM 7} OAH EDS
< Notes Done < Notes Done
October 1, 2013, 12:14 PM October 1, 2013, 12:11 PM
He was new to China. In fact, his He was new to China. In fact, his
first words were, * : first words were, * E383]
KR RK RARE @
it.) Each time you tap it, you rotate to the next keyboard you requested
earlier. The new language’s name appears briefly on the space bar to.
identify it.
Thanks to that ® button, you can freely mix languages and alphabets
within the same document without having to duck back to some control
panel to make the change. And thanks to the iPhone's virtual keyboard,
the actual letters on the “keys” change in real time.
The ® button works in three ways:
* Tap it once to restore the most recent keyboard. Great if you're fre-
quently flipping back and forth between two languages.
* Tap it rapidly to cycle among all the keyboards you've selected. (The
name of the language appears briefly on the space bar to help you
out.)
* If you, some United Nations translator, like to write in a lot of differ-
ent languages, you don’t have to tap that @ key over and over again
to cycle through the keyboard layouts. Instead, hold your finger down
Typing, Editing & Searching 85