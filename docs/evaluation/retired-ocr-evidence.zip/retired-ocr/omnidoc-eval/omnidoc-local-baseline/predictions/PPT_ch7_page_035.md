7.3 Linear Systems of Equations. Gauss Elimination
Matrix Form of the Linear System (1). (continued)
We assume that the coefficients a, are not all zero, so that A
is not a zero matrix. Note that x has n components, whereas
b has m components. The matrix
ay, A, : b,
A=
a 'b
m1 mn + ~m
a
is called the augmented matrix of the system (1). The
dashed vertical line could be omitted, as we shall do later.
It is merely a reminder that the last column of A did not
come from matrix A but came from vector b. Thus, we
augmented the matrix A.
Section 7.3 p35 Advanced Engineering Mathematics, 10/e by Edwin Kreyszig
Copyright 2011 by John Wiley & Sons. All rights reserved.