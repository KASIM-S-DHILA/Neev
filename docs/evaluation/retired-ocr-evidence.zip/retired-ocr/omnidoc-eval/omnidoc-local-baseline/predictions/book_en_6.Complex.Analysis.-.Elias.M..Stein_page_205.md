186 Chapter 7. THE ZETA FUNCTION AND PRIME NUMBER THEOREM
which holds for 0 < x < 1, we find that
_ 1 _ye
Since the double sum converges absolutely, we need not specify the order
of summation. See the Note at the end of this chapter. ‘The formula
then holds for all Re(s) > 1 by analytic continuation. Note that, by
Theorem 6.2 in Chapter 3, log ¢(s) is well defined in the simply connected
half-plane Re(s) > 1, since ¢ has no zeros there. Finally, it is clear that
we have
log ¢(s) =
pam n=l
where ¢,, = 1/m if n= p™ and ¢, = 0 otherwise.
The proof of the theorem we shalll give depends on a simple trick that
is based on the following inequality.
Lemma 1.4 If €R, then 3+ 4cos0 + cos20 > 0.
This follows at once from the simple observation
3+ 4cos6 + cos 20 = 2(1 + cos8)?.
Corollary 1.5 If > 1 and t is real, then
log |¢*(o)¢4(o + it)¢(o + 2it)| > 0.
Proof. Let s =o + it and note that
Re(n~*) = Re(eW (7) 28") = e-7 8 cos(tlog n) = n~? cos(t log n).
Therefore,
log |G3(a)¢4( + it)C(o + 2it)|
0g |¢(a)| + Alog |C(a + it)| + log |¢(o + 2it)]
ellog ¢(o)] + 4Rellog ¢(a + it)] + Reflog ¢( + 2it)}
= Venn? (3 + 4.0080 + 608 20m),
where 6, = tlogn. The positivity now follows from Lemma 1.4, and the
fact that cn 2 0.