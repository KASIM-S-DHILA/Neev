ABE SE
www.Jinghua.com “¢c2 “ili” —~ VERS SR PRBERHE MS FR www.Jinghua.com
25. ----_____ won the first place in the “Super Girl” singing competition?
---- Lucy did.
A. Who B. When C. Where D. Why
26. Shops in big Cities are ___than those in the country.
A. expensive B. more expensive
C. most expensive D. the most expensive
27. You play football in the street. It’s too dangerous.
A. wouldn’t B. needn’t C. mustn't D. couldn't
28. It’ s snowing now. You'd better___ your car slowly on a snowy day.
A. drive B. drove C. driving D. to drive
29. My little brother asks me ___ hima story every day.
A. tell B. told C. telling D. to tell
30. Today, more and more people enjoy____ things online.
A. buy B. bought C. buying D. to buy
31. Don’t turn on the radio. Grandpa ____ now.
A. sleeps B. is sleeping C. has slept D. slept
32. ---- Have you ever seen the cartoon Tom and Jerry?
-Yes.1_____ it many times.
B. saw C. will see D. have seen
by my mum just now. would you like to have some?
~ Yes, please.
A. was made. B. made C. is made D. makes
~ Could you please tell us the Would Expo in Shanghai?
- In July.
A. when you will visit B. why you will visit C. when will you visit D. why will you visit
---- Yes, please. I want to buy some CDs for my son,
A. How do you do B. What's wrong with you
C. Can I help you D. Is that Mary speaking
Ti, FEES. E12 S, BEAL 1 4d)
I watched as my little brother was caught in the act. He was sitting in the corner of the living room, a__
36 in one hand and my father’s hymnbook (#3¢i44{£) in the other.
As my father walked into the room, my brother cowered slightly (4#(#s [L4ii) . He sensed that he had
done something ___37__. Icould see thathe had __38 __ my father’s new hymnal and scribbled (#L.
¥Y®) in it. Now he was waiting for his punishment.
For my father, books were knowledge. They were important to him. And yet he*loved his children.
What he did next was __39 _. Instead of punishing my brother, he sat down, took the pen from my
brother's hand, and then wrote in the book himself, alongside the scribbles John had made: “__40__work,
1959, age 2.” How many times have I looked into your beautiful face and into your warm eyes looking up at
~ 3H ~
: www.Jinghua.com
+ 400-650-7766 (9: 00—21: 00 everyday) WOBUIAT ACY EBT PEAT BRAS