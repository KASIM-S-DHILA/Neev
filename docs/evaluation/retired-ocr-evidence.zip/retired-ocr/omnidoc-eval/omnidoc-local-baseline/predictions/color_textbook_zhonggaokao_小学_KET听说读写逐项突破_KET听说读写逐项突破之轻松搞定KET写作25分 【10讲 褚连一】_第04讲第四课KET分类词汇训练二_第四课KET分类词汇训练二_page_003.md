KET FRA LMA
painter
photography
pratice/pratise
prize
programme
project
website
present
actor
artist
businessman
painter n. 3
photography n. 44%
pratice/pratise nJ/v. 25), H3%
prize n. &&%
programme n. #7 8
Project n. #2. 8
website n. 35
present n. #L3
actor n. 3% HK
artistn. BRE
businessman n. # A
KET FRA LIK
engineer
guest
guide
hairdresser
instructions
nurse
occupation
pharmacy
photographer
receptionist
secretary
engineer n. 1.42)
guest n, BA
guide n. 3] $45. 48%
hairdresser n. 2 20%
instructions n. #6945
nurse n. 4? +
occupation n. 4% 3k
pharmacy n. 3
photographer n.d #6
receptionist n. 4£45 i
secretary n. #45
KET FAA LAA
chemist
cleaner
colleague
company
computer
customer
dentist
diploma
doctor
driver
earn
chemist n. LER, HAF
cleaner n, #75
colleague n. F]
company n. 2S 4)
computer n. fii
customer n. A #
dentist n. 7K
diploma n. £4
doctor n. &
driver n, 44
earn v. IRAP, BEAR
KET # RA LIK
shop assistant
staff
uniform
accident
appointment
arm
body
back
check
dangerous
dentist
shop assistant n. Jé ii
staffn. SKAR, FF
uniform n. #1 JR
accident n. ¥ &. 9b
appointment n. 2. 74
arm n. $4f
body n. 4 4
backn. BH, #4
check nJv. #2
dangerous a. f, Rr4)
dentist n. 7K