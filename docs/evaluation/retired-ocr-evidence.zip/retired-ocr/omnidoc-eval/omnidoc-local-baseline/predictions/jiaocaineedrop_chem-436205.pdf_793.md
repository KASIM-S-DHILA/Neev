LibreTexts
A Zz
‘| | Iho od 4
xy xz yz xy XZ yz
Small A, (Weak Field) Large A, (Strong Field)
Figure 7: The difference between d-orbitals in metal ions is Ao, which influences their electron spin. If Ao is small, then it requires
less energy for the electrons to move up into a higher energy orbital than it does to pair up, but when A\o is large, the jump into the
next orbital would be too high. Note that this only impacts dy-dy electrons.
Some of the factors that contribute to Ao include the formal charge of the ion, the location of the ion on the periodic table, and the
types of ligands in the system. All of the donor atoms in the binding site of lactoferrin (except histidine) are sigma and pi donors.
Sigma and pi donors are typically involved in weak field interactions, which is a smaller distance between d-orbitals (Ao). In
addition, iron (III) has a location in the fourth row of the periodic table, and Ao decreases going up the periodic table. These factors
indicate that iron (III) in lactoferrin has a weak field. Since Iron (III) is a d° electron, a weak field means that iron’s d-electrons will
occupy the higher energy orbitals, and won’'t pair up.
Ligand field stabilization energy (LFSE) can suggest the preferred geometry of an ion. The LFSE is calculated using the equation
LFSE = -0.4x + 0.6y, where x is equal to the number of electrons in lower energy orbitals, and y is equal to the number of electrons
in higher energy orbitals. Iron (11) has a LFSE of zero, which means there is no other ligand position that would provide a lower
LFSE, and so iron is able to form stable bonds in any geometry configuration. Usually d? metal ions form an octahedral complex
when bound to six ligands (See figure 8). However, in the case of lactoferrin, the carbonate ion causes a slight change in the
geometry which results in a distorted octahedral configuration,