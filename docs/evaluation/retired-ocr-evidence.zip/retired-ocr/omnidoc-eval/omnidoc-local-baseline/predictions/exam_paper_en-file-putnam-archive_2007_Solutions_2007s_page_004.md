B-2 Put B= maxo<
B-3 First solution:
1Lf"(x)| and g(x) = fe f(y) dy. Since
the maximum value of |g(x)| must oc-
cur at a critical point y € (0,1) satisfying g’(y) = f(y) =
0. We may thus take a = y hereafter.
Since fi f(x)dx = — fp“ f(1 —x) dx, we may assume
that @ < 1/2. By then substituting —f(x) for f(x) if
needed, we may assume that fy‘ f(x)dx > 0. From the
inequality f’(x) > —B, we deduce f(x) < B(a —x) for
0<x<a,s0
fF sooacs ["a(a-xax
$a(a—»
1
Pe
=lB< 3B
2°78
as desired.
Observing that x3/2 = 13, 33/4 = 34,
x4/8 = 89, we guess that x, = 2” Fans,
5	1	15	1	2	11	409	469	38	11	92.453812	where
5	1	15	1	2	12	454	469	12	13	41.085682	Fi
5	1	15	1	2	13	474	468	9	12	90.450348	is
4	1	15	1	3	0	128	487	354	14	-1	
5	1	15	1	3	1	128	487	18	11	93.890289	the
5	1	15	1	3	2	153	487	25	11	91.429962	k-th
5	1	15	1	3	3	185	487	62	11	93.890182	Fibonacci
5	1	15	1	3	4	255	487	50	11	86.907806	number.
5	1	15	1	3	5	317	487	32	11	72.438263	‘Thus
5	1	15	1	3	6	356	490	18	8	96.499046	we
5	1	15	1	3	7	380	487	35	11	95.525169	claim
5	1	15	1	3	8	423	487	23	11	95.384132	that
5	1	15	1	3	9	452	491	13	10	73.551132	x,
5	1	15	1	3	10	472	492	10	4	90.130562	=
2	1	16	0	0	0	129	502	354	26	-1	
3	1	16	1	0	0	129	502	354	26	-1	
4	1	16	1	1	0	129	502	354	26	-1	
5	1	16	1	1	1	129	498	22	34	15.744461	22
5	1	16	1	1	2	157	506	42	17	35.432320	(3
—a-O"9), where @ = 4¥5, to make the
2006
answer xagor = 2% (0397 — a?)
We prove the claim by induction; the base case 1x9 = 1 is
true, and so it suffices to show that the recursion x
3x + [xn V5] is satisfied for our formula for x,. Indeed,
5 _g-(2n+5))
= B+ V3)(a2"3 — o-2H*3)))
=r @- m3),
Now 2"@-2"+3) = (4S6- V5)" is between —1
and 0; the recursion follows since x,.%,+1 are integers.
Second solution: (by Catalin Zara) Since x, is rational,
we have 0 <.%V5— [nV5| <1. We now have the
inequalities
Ang —3Xn <AnV5 < Ang — 3x + 1
(84 V5)xn—1 < ans <(34+V5)xn
xy — (3 — V5) < (3—V5)xinvt < 4am
Bxng1 —4n < ang V5 < 3ane1 —4an + (3 — V5).
Since 0 <3 — V5 <1, this yields [x41 V5] = 3x41 —
Ayn, SO We can rewrite the recursion as xn y1 = 6x, —
4xn—1 for n> 2. It is routine to solve this recursion to
obtain the same solution as above.
Remark: — With an initial 1 prepended, this
becomes sequence 018903 in Sloane’s On-
Line Encyclopedia of Integer Sequences:
(attp://www.research.att.com/"njas/
4
sequences/). Therein, the sequence is described as
the case S(1,5) of the sequence S(ao,a1) in which dy2
is the least integer for which ayn42/any1 > dnsi/dn.
Sloane cites D. W. Boyd, Linear recurrence relations
for some generalized Pisot sequences, Advances in
Number Theory (Kingston, ON, 1991), Oxford Univ.
Press, New York, 1993, p. 333-340.
B-—4 The number of pairs is 2”*!. The degree condition
forces P to have degree n and leading coefficient +1;
‘we may count pairs in which P has leading coefficient
1 as long as we multiply by 2 afterward.
Factor both sides:
(P(X) + Q(X)i)(P(X) ~ Q(X)i)
= [JX -exp(2mi(2j+1)/(4n)))
i
To +exp(2mi(2j+1)/(4n)))
jo
Then each choice of P,Q corresponds to equating
P(X) + O(X)i with the product of some n factors on
the right, in which we choose exactly of the two fac-
tors for each j =0,...,n—1. (We must take exactly n
factors because as a polynomial in X with complex co-
efficients, P(X) + Q(X)i has degree exactly n, We must
choose one for each j to ensure that P(X) + Q(X)i and
P(X) —Q(X)i are complex conjugates, so that P,Q have
real coefficients.) Thus there are 2” such pairs; multi-
plying by 2 to allow P to have leading coefficient —1
yields the desired result.
Remark: If we allow P and Q to have complex coeffi-
cients but still require deg(P) > deg(Q), then the num-
ber of pairs increases to 2(>"), as we may choose any n
of the 2n factors of X2” +1 to use to form P(X) +O(X)i.
B-S For n an integer, we have |f| = 7!
5	1	42	1	1	11	804	793	18	11	92.698502	for
5	1	42	1	1	12	827	797	6	11	92.682762	j
5	1	42	1	1	13	840	793	18	11	95.386986	the
5	1	42	1	1	14	865	796	43	12	96.444099	unique
2	1	43	0	0	0	553	810	355	16	-1	
3	1	43	1	0	0	553	810	355	16	-1	
4	1	43	1	1	0	553	810	355	16	-1	
5	1	43	1	1	1	553	811	44	15	72.135117	integer
5	1	43	1	1	2	601	815	11	7	72.135117	in
5	1	43	1	1	3	618	810	66	16	52.580757	{0,...,k—
5	1	43	1	1	4	690	810	12	16	52.580757	1}
5	1	43	1	1	5	707	813	64	13	96.827057	congruent
5	1	43	1	1	6	776	813	11	9	93.387924	to
5	1	43	1	1	7	791	815	7	7	42.503761	1
5	1	43	1	1	8	803	811	48	11	93.187416	modulo
5	1	43	1	1	9	855	811	11	13	91.664841	k;
5	1	43	1	1	10	872	811	36	11	96.786888	hence
2	1	44	0	0	0	630	846	19	8	-1	
3	1	44	1	0	0	630	846	19	8	-1	
4	1	44	1	1	0	630	846	19	8	-1	
5	1	44	1	1	1	630	846	19	8	65.501678	kel
2	1	45	0	0	0	553	909	355	92	-1	
3	1	45	1	0	0	553	909	355	34	-1	
4	1	45	1	1	0	554	909	354	15	-1	
5	1	45	1	1	1	554	910	17	14	96.851021	By
5	1	45	1	1	2	575	909	66	15	95.695610	expanding
5	1	45	1	1	3	646	909	22	12	96.899178	this
5	1	45	1	1	4	673	912	23	10	96.899178	out,
5	1	45	1	1	5	702	913	17	8	96.990982	we
5	1	45	1	1	6	724	909	39	12	96.901230	obtain
5	1	45	1	1	7	768	910	19	11	96.901230	the
5	1	45	1	1	8	791	909	46	12	93.279037	desired
5	1	45	1	1	9	842	909	66	15	69.938911	polynomi-
4	1	45	1	2	0	553	927	141	16	-1	
5	1	45	1	2	1	553	928	17	11	93.302200	als
5	1	45	1	2	2	575	927	119	16	0.000000	P)(n),.-..Pe-(n).
3	1	45	2	0	0	553	953	355	48	-1	
4	1	45	2	1	0	553	953	355	15	-1	
5	1	45	2	1	1	553	953	60	11	96.004837	Remark:
5	1	45	2	1	2	620	953	51	11	96.794281	Variants
5	1	45	2	1	3	675	953	14	11	94.860779	of
5	1	45	2	1	4	692	953	22	11	83.794792	this
5	1	45	2	1	5	725	953	44	11	83.794792	solution
5	1	45	2	1	6	774	956	18	8	96.834984	are
5	1	45	2	1	7	797	956	51	12	91.846237	possible
5	1	45	2	1	8	853	953	23	11	93.037720	that
5	1	45	2	1	9	880	956	28	8	92.258652	con-
4	1	45	2	2	0	553	971	355	15	-1	
5	1	45	2	2	1	553	973	35	9	96.031349	struct
5	1	45	2	2	2	592	971	19	11	93.306129	the
5	1	45	2	2	3	615	971	10	14	78.345078	P;
5	1	45	2	2	4	630	971	23	11	95.095024	less
5	1	45	2	2	5	657	971	63	15	96.766617	explicitly,
5	1	45	2	2	6	725	974	33	12	96.942009	using
5	1	45	2	2	7	763	971	59	15	96.594460	Lagrange
5	1	45	2	2	8	827	971	81	15	96.957802	interpolation
4	1	45	2	3	0	553	990	190	11	-1	
5	1	45	2	3	1	553	993	13	8	94.730042	or
5	1	45	2	3	2	571	990	88	11	94.730042	Vandermonde
5	1	45	2	3	3	664	990	79	11	94.743057	determinants
2	1	46	0	0	0	705	953	136	11	-1	
3	1	46	1	0	0	705	953	136	11	-1	
4	1	46	1	1	0	705	953	136	11	-1	
5	1	46	1	1	1	705	957	20	7	95.000000	 
5	1	46	1	1	2	813	953	28	11	95.000000	 
2	1	47	0	0	0	743	993	3	8	-1	
3	1	47	1	0	0	743	993	3	8	-1	
4	1	47	1	1	0	743	993	3	8	-1	
5	1	47	1	1	1	743	993	3	8	95.000000	 
2	1	48	0	0	0	520	1021	388	15	-1	
3	1	48	1	0	0	520	1021	388	15	-1	
4	1	48	1	1	0	520	1021	388	15	-1	
5	1	48	1	1	1	520	1021	26	11	89.256821	B-6
5	1	48	1	1	2	553	1021	71	15	94.191391	(Suggested
5	1	48	1	1	3	628	1021	15	15	96.969597	by
5	1	48	1	1	4	648	1021	30	15	93.272202	Oleg
5	1	48	1	1	5	683	1021	57	15	92.731888	Golberg)
5	1	48	1	1	6	745	1022	50	10	92.877899	Assume
5	1	48	1	1	7	800	1025	7	7	66.115921	n
5	1	48	1	1	8	812	1022	10	13	85.863548	>
5	1	48	1	1	9	828	1021	10	12	85.863548	2,
5	1	48	1	1	10	843	1025	13	7	94.268646	or
5	1	48	1	1	11	860	1021	24	11	94.268646	else
5	1	48	1	1	12	889	1021	19	11	96.849060	the
2	1	49	0	0	0	553	1040	355	70	-1	
3	1	49	1	0	0	553	1040	355	70	-1	
4	1	49	1	1	0	553	1040	354	14	-1	
5	1	49	1	1	1	553	1040	53	14	95.010750	problem
5	1	49	1	1	2	611	1043	9	8	86.940735	is
5	1	49	1	1	3	625	1040	49	14	86.940735	trivially
5	1	49	1	1	4	680	1040	32	11	95.622986	false.
5	1	49	1	1	5	718	1040	76	14	96.516281	Throughout
5	1	49	1	1	6	798	1040	23	11	96.516281	this
5	1	49	1	1	7	826	1040	37	14	88.677261	proof,
5	1	49	1	1	8	868	1043	22	11	93.184563	any
5	1	49	1	1	9	895	1040	12	13	82.987091	C;
4	1	49	1	2	0	553	1058	355	15	-1	
5	1	49	1	2	1	553	1058	23	12	93.701866	will
5	1	49	1	2	2	583	1058	14	12	93.701866	be
5	1	49	1	2	3	603	1062	6	8	93.446014	a
5	1	49	1	2	4	615	1061	49	12	93.446014	positive
5	1	49	1	2	5	669	1060	53	10	95.990463	constant
5	1	49	1	2	6	728	1058	40	12	96.891945	whose
5	1	49	1	2	7	773	1060	34	10	96.610374	exact
5	1	49	1	2	8	812	1058	33	12	96.610374	value
5	1	49	1	2	9	852	1058	9	12	83.216171	is
5	1	49	1	2	10	867	1058	41	12	83.216171	imma-
4	1	49	1	3	0	553	1077	355	15	-1	
5	1	49	1	3	1	553	1077	36	11	95.508644	terial.
5	1	49	1	3	2	599	1077	16	11	95.508644	As
5	1	49	1	3	3	622	1077	11	11	96.418526	in
5	1	49	1	3	4	639	1077	19	11	96.441055	the
5	1	49	1	3	5	664	1077	35	15	87.485901	proof
5	1	49	1	3	6	704	1077	14	11	93.306053	of
5	1	49	1	3	7	723	1077	58	15	89.867569	Stirling’s
5	1	49	1	3	8	787	1077	96	15	86.913063	approximation,
5	1	49	1	3	9	890	1080	18	8	89.993698	we
4	1	49	1	4	0	553	1095	183	15	-1	
5	1	49	1	4	1	553	1097	52	9	94.723694	estimate
5	1	49	1	4	2	611	1095	18	11	96.922600	for
5	1	49	1	4	3	633	1098	22	12	94.408386	any
5	1	49	1	4	4	661	1095	30	11	93.289452	fixed
5	1	49	1	4	5	696	1099	7	7	43.309040	c
5	1	49	1	4	6	708	1097	8	10	85.959572	€
5	1	49	1	4	7	722	1095	14	13	85.959572	R,
2	1	50	0	0	0	566	1130	178	33	-1	
3	1	50	1	0	0	566	1130	178	33	-1	
4	1	50	1	1	0	566	1130	178	33	-1	
5	1	50	1	1	1	562	1130	11	32	40.132149	Y
5	1	50	1	1	2	583	1137	22	21	45.105850	(i+
5	1	50	1	1	3	611	1145	57	4	22.425682	e)logi=
5	1	50	1	1	4	674	1130	17	33	1.756714	FP
5	1	50	1	1	5	700	1137	30	18	1.756714	logn
5	1	50	1	1	6	735	1147	9	1	92.570786	-
2	1	51	0	0	0	769	1137	86	18	-1	
3	1	51	1	0	0	769	1137	86	18	-1	
4	1	51	1	1	0	769	1137	86	18	-1	
5	1	51	1	1	1	769	1137	5	8	85.386848	?
5	1	51	1	1	2	780	1142	9	11	91.745705	+
5	1	51	1	1	3	793	1140	62	15	76.795547	O(nlogn)
2	1	52	0	0	0	746	1130	21	33	-1	
3	1	52	1	0	0	746	1130	21	33	-1	
4	1	52	1	1	0	746	1130	21	33	-1	
5	1	52	1	1	1	746	1130	21	33	95.000000	 
