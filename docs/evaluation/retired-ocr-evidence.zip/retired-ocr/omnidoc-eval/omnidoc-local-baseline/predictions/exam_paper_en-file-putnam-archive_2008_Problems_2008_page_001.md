The 69th William Lowell Putnam Mathematical Competition
Saturday, December 6, 2008
Al Let f: R? +R bea function such that f(x,y) +0:
J(c.x) =0 for all real numbers x, y, and z. Prove that
there exists a function g: R > R such that f(x,y
g(x) — g(y) for all real numbers x and y,
A2 Alan and Barbara play a game in which they take turns
filling entries of an initially empty 2008 x 2008 array.
Alan plays first. At each turn, a player chooses a real
number and places it in a vacant entry. The game ends
when all the entries are filled. Alan wins if the determi-
nant of the resulting matrix is nonzero; Barbara wins if
it is zero. Which player has a winning strategy?
AB Start with a finite sequence ay,a3,...,4y of positive in-
tegers. If possible, choose two indices j <k such that ay
does not divide ay, and replace aj and ay by ged(aj,a4)
and lem(aj,a,), respectively. Prove that if this process
is repeated, it must eventually stop and the final se-
quence does not depend on the choices made, (Note:
ged means greatest common divisor and lem means
least common multiple.)
A4 Define f : RR by
ifx<e
x
f= {ram ifx>e.
Does Er zn) converge?
AS Let n> 3 be an integer. Let f(x) and g(x) be poly-
nomials with real coefficients such that the points
F(1),8(1))-(F(2),8(2)).---+(F(n),9(n)) in R? are the
vertices of a regular n-gon in counterclockwise order.
Prove that at least one of f(x) and g(x) has degree
greater than or equal ton — 1
AG Prove that there exists a constant ¢ > 0 such that in ev-
ery nontrivial finite group G there exists a sequence of
length at most clog|G| with the property that each el-
ement of G equals the product of some subsequence.
(The elements of G in the sequence are not required to
be distinct. A subsequence of a sequence is obtained
by selecting some of the terms, not necessarily con:
utive, without reordering them; for example, 4,4,2
subsequence of 2,4,6,4,2, but 2,2,4 is not.)
BI Whatis the maximum number of rational points that can
lie on a circle in R? whose center is nota rational point?
(A rational point is a point both of whose coordinates
are rational numbers.)
B2 Let F(x) = Inx. For n > 0 and x > 0, let Fyyi(x) =
fe Fa(t) dt. Evaluate
in(d
tim” i ;
B3 What is the largest possible radius of a circle contained
in a 4-dimensional hypercube of side length 1?
B4 Let p be a prime number. Let h(x) be a polynomial with
integer coefficients such that /(0),h(1),..-(p? — 1)
are distinct modulo p?. Show that h(0),h(1),...,h(p3 —
1) are distinct modulo p3.
BS Find all continuously differentiable functions f:R +R
such that for every rational number g, the number f(q)
is rational and has the same denominator as g. (The
denominator of a rational number q is the unique posi-
tive integer b such that q = a/b for some integer a with
gcd(a,b) = 1.) (Note: ged means greatest common di-
visor.)
B6 Let n and k be positive integers. Say that a permutation
6 of {1,2,....n} is k-limited if |o(i) — i] < k for all
i. Prove that the number of k-limited permutations of
{1,2,...,m} is odd if and only ifn =0 or I (mod 2k-+ 1).