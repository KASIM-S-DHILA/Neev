Solutions to the 60th William Lowell Putnam Mathematical Competition
Saturday, December 4, 1999
Manjul Bhargava, Kiran Kedlaya, and Lenny Ng
AGI Note that if r(x) and s(x) are any two functions, then
max(r,s) = (r-+5+|r—s|)/2.
‘Therefore, if F(x) is the given function, we have
F(x) =max{—3x—3,0} —max{5x,0} +3x-+2
= (-3r-34[3x+3))/2
~ (Sx+|Sx|)/2+3x+2
= [Gr+3)/2|-[5x/2|-x+4,
(2) = Gr+3)/2, @)
so we may s 5x/2, and
h(x) = -x+4.
A-2 First solution: First factor p(x) = q(x)r(x), where q has
all real roots and r has all complex roots. Notice that
each root of g has even multiplicity, otherwise p would
have a sign change at that root. Thus q(x) has a square
root s(x)
Now write r(x
Tis —a))(x- a) (possible be-
cause r has roots in complex conjugate pairs). Write
TI}: («= ay) = (x) + iu(x) with ¢,x having real coeffi-
cients. Then for x real,
P(x) =a(a)r(x)
8(x)?(t(x) +iu(x)) (FQ) + iu)
(s(a)e(a))? + (s(a)u(a)?.
(Alternatively, one can factor r(x) as a product of
quadratic polynomials with real coefficients, write each
as a sum of squares, then multiply together to get a sum
of many squares.)
Second solution: We proceed by induction on the de-
gree of p, with base case where p has degree 0. As in
the first solution, we may reduce to a smaller degree in
case p has any real roots, so assume it has none. Then
p(x) > 0 for all real x, and since p(x) > e for x —» +00,
p has a minimum value c, Now p(x) —c has real roots,
so as above, we deduce that p(x) ~c is a sum of squares.
Now add one more square, namely (,/¢), to get p(x)
as a sum of squares.
A-3 First solution: Computing the coefficient of x"*" in the
identity (1 —2x—27) Y"_g.an.x” = 1 yields the recur-
Fence Gy+| = 2dy + an—13 the sequence {ay} is then
characterized by this recurrence and the initial condi-
Define the sequence {D,} by bay =a2_, +42, bon =
y(dy—1 + ny 1)- Then
Wan + Bon = 2andtns + 2dn—1n Fay +a
= Banding) + ann st +
= ann $y = brnsas
and similarly 2b, + byn—1 = bn1, $0 that {by} satis
fies the same recurrence as {a,}. Since further by =
1,b; = 2 (where we use the recurrence for {a,} to cal-
culate a_; = 0), we deduce that by = ay for all n. In
particular, a7 +a?
1 = bn2 = dong.
Second solution: Note that
1
[oho
at (_v+t v2-1
~ 22 \1-(14 v2)x | 1 (1- V2)
and that
1 5
= P14: v2)"x"",
1+(1+ V2)x x y
so that
1 ntl ned
35
5	1	42	1	10	2	646	721	116	29	3.169472	((va+y™-(1-
5	1	42	1	10	3	769	721	77	29	3.169472	v3).
A simple computation (omitted here) now shows that
B+ ah, = arns2.
Third solution (by Richard Stanley): Let A be the matrix
(7 »): A simple induction argument shows that
12
amr (an Ans
Bn An42,
The desired result now follows from comparing the top
left corner entries of the equality A”*2A"? = A’"*4,
A-4 Denote the series by S, and let a, = 3"/n. Note that
Sol
s x x Gmn(4m + dn)
Sel
HS nan + an)”
where the second equality follows by interchanging m