Revision 2

Let's Review

A Look, listen and choose.

B Choose and say.

Name: Nancy
Favourite things: animals
and plants
Good at: planting flowers
Wants to be: a farmer

Name: Ann
Favourite things: delicious food
Good at: cooking
Wants to be: a cook

Name: Sam
Favourite things: cars
Good at: driving bumper cars
Wants to be: a driver