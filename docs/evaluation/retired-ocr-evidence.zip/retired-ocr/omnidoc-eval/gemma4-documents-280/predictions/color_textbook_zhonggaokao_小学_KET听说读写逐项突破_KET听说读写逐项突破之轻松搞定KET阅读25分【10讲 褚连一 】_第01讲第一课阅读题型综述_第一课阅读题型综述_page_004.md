| Part 4 祥趣表演 | Part 5 祥趣表演 |
| :--- | :--- |
| Ana Johnson is a 13-year-old swimmer who lives in Melbourne in Australia. Her dream is to swim for Australia in the next Olympics. She swims in both long and short races and she has already come first in many important competitions. | A famous circus. It was started (28) ... Montreal, Canada. It was started (28) ... The Canadian Guy Laliberté in 1984. When he left college, Laliberté traveled around Europe and earned money (29) ... music in the streets. Example: 0 A in B at C to Answer: A 28 A from B by C 29 A played B plays C playing |
| Example: 0 Ana's home is in Melbourne. A Right B Wrong C Doesn't say | Example: 0 A in B at C to Answer: A 28 A from B by C 29 A played B plays C playing |
| 21 Ana hopes she will become an Olympic swimmer. A Right B Wrong C Doesn't say | |
| 22 Ana knows that she is better at short races than long ones. A Right B Wrong C Doesn't say | |
| 23 | |
| 30 A their B his C its | |
| 31 A some B all C enough | |
| 32 A more B much C many | |
| 33 | |
| 34 | |
| 35 | |
| 36 | |
| 37 | |
| 38 | |
| 39 | |
| 40 | |
| 41 | |
| 42 | |
| 43 | |
| 44 | |
| 45 | |
| 46 | |
| 47 | |
| 48 | |
| 49 | |
| 50 | |
| 51 | |
| 52 | |
| 53 | |
| 54 | |
| 55 | |
| 56 | |
| 57 | |
| 58 | |
| 59 | |
| 60 | |
| 61 | |
| 62 | |
| 63 | |
| 64 | |
| 65 | |
| 66 | |
| 67 | |
| 68 | |
| 69 | |
| 70 | |
| 71 | |
| 72 | |
| 73 | |
| 74 | |
| 75 | |
| 76 | |
| 77 | |
| 78 | |
| 79 | |
| 80 | |
| 81 | |
| 82 | |
| 83 | |
| 84 | |
| 85 | |
| 86 | |
| 87 | |
| 88 | |
| 89 | |
| 90 | |
| 91 | |
| 92 | |
| 93 | |
| 94 | |
