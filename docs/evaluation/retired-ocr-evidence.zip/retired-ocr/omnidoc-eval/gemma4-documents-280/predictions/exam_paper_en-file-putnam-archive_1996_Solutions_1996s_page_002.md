Therefore
$(a, z_1, a_2, a_3, a_4) \in S \Rightarrow (a, a_1, a_2, a_3) \in S \Rightarrow (a, z_1, a_2, a_3) \in S$
$(a, z_1, a_2, a_3) \in S \Rightarrow (a, z_1, a_2, a_3) \in S \Rightarrow (a, z_1, a_2, a_3) \in S$
$(a, z_1, a_2, a_3) \in S \Rightarrow (a, z_1, a_2, a_3) \in S \Rightarrow (a, z_1, a_2, a_3) \in S$
$s(a, z_1, a_2, a_3) \in S$. The case $j=i+1$ is ruled out by
$s(a, z_1, a_2, a_3) \in S \Rightarrow s(a, z_1, a_2, a_3) \in S \Rightarrow s(a, z_1, a_2, a_3) \in S$
and the case $j=i-1$ is ruled out by
Finally, we put $g(x)$ in $\{g(a_i), \dots, g(a_n)\}$ if $n$ is
$1 \le n \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$, $1 \le p$,