| | | |
| :--- | :--- | :--- |
| **7.6 For Reference: Cramer's Rule for Linear Systems of Three Equations** | | |
| (5) | $a_{11}x_{1} + a_{12}x_{2} + a_{13}x_{3} = b_{1}$ | |
| | $a_{21}x_{1} + a_{22}x_{2} + a_{23}x_{3} = b_{2}$ | |
| | $a_{31}x_{1} + a_{32}x_{2} + a_{33}x_{3} = b_{3}$ | |
| is | | |
| (6) | $x_{1} = \frac{D_{1}}{D}$, $x_{2} = \frac{D_{2}}{D}$, $x_{3} = \frac{D_{3}}{D}$ ($D \neq 0$) | |
| with the determinant $D$ of the system given by (4) and | | |
| $D_{1} = \begin{vmatrix} b_{1} & a_{12} & a_{13} \\ b_{2} & a_{22} & a_{23} \\ b_{3} & a_{32} & a_{33} \end{vmatrix}$, $D_{2} = \begin{vmatrix} a_{11} & b_{1} & a_{13} \\ a_{21} & b_{2} & a_{23} \\ a_{31} & b_{3} & a_{33} \end{vmatrix}$, $D_{3} = \begin{vmatrix} a_{11} & a_{12} & b_{1} \\ a_{21} & a_{22} & b_{2} \\ a_{31} & a_{32} & b_{3} \end{vmatrix}$ | |
| Note that $D_{1}, D_{2}, D_{3}$ are obtained by replacing Columns 1, 2, 3, respectively, by the column of the right sides of (5). | | |
| Section 7.6 p90 | Advanced Engineering Mathematics, 10/e by Edwin Kreyszig | Copyright 2011 by John Wiley & Sons. All rights reserved. |