7.3 Linear Systems of Equations. Gauss Elimination
Matrix Form of the Linear System (1). (continued)
We assume that the coefficients $a_{ij}$ are not all zero, so that $A$ is not a zero matrix. Note that $x$ has $n$ components, whereas $b$ has $m$ components. The matrix
$$\tilde{A} = \begin{bmatrix} a_{11} & \cdots & a_{1n} & b_1 \\ \vdots & \ddots & \vdots & \vdots \\ a_{m1} & \cdots & a_{mn} & b_m \end{bmatrix}$$
is called the augmented matrix of the system (1). The dashed vertical line could be omitted, as we shall do later. It is merely a reminder that the last column of $\tilde{A}$ did not come from matrix $A$ but came from vector $b$. Thus, we augmented the matrix $A$.

Section 7.3 p35
Copyright 2011 by John Wiley & Sons. All rights reserved.