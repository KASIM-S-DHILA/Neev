| Text |
|---|
| Mediterranean (地中海) countries about 6,000 years ago. ago to make trees at the time of the ancient Greeks, they used olive trees. A. |
| 80.D symbol explanation. In the ancient times, olive trees were used for oil, and they were used for food, and they were used for clothing, and they were used for many things. A. |
| 81.B symbol explanation. In Ancient Greece, for example, anyone who cut down an olive tree was heavily punished. A. |
| 82.D symbol explanation. In Ancient Greece, for example, anyone who cut down an olive tree was heavily punished. A. |
| Note: The olive tree was used for oil, and it was used for food, and it was used for clothing, and it was used for many things. A. |
| While many young people were enjoying the summer vacation, Zach Bonner was working his hardest. Zach started walking from Valrico, Florida, his hometown, on Christmas, 2009. He reached Los Angeles nine months later in September, 2010. He covered a total of 2,478 miles and raised $120,000 for kids in need. Along the way, Zach attended school online. His mother, brother and sister took turns to walk or drive together with him. |
| Although he is very young, Zach has a long history of helping others. When a terrible storm hit town in 2004, Zach, when six, pulled a wagon (小车) through his community and collected food for people in need. |
| He has raised $400,000 for his Little Red Wagon Foundation since then. It gives money to projects which help homeless children. In 2007, Zach began walking to support a children's charity (慈善组织) in Tampa, Florida. He finished his journey 23 days later, 280 miles away in Tallahassee. Then in the summer of 2009, he trekked about 670 miles from Atlanta to Washington, D.C., in just two months. |
| "As long as there are homeless kids, I will never stop walking for them." Zach says. |
| 83. What did Zach do during the summer vacation in 2010? A. He stayed at home to look after his family. B. He traveled to his hometown with his family. C. He joined in a school activity with other kids. D. He walked to collect money for kids in need. |
| 84. We can learn from Paragraph 2 that Zach |
| A. began to help people at a very early age. B. made money to pay for his education. C. enjoyed playing around in his community. D. worked hard for his family. |
| 85. At what age did Zach start walking to support a Tampa children's charity? A. At six. B. At nine. C. At eleven. D. At twelve. |