```markdown
(by elementary algebra, or Cramer's rule), so the center of
the circle is rational. This proves the desired result.
Remark: The above solution is deliberately more ver-
bose than it really is. A shorter way to say this
is that any two rational points determine a line.
This is any two rational points determine a line.
a line (a line of the form $ax+by=c$ with $a,b \in \mathbb{Q}$,
rational), while any two nonparallel rational lines inter-
sect at a rational point. A similar statement holds
with the rational numbers replaced by any field.
Remark: A more explicit argument is to show that
the equation of the circle through the rational points
$(x_1, y_1), (x_2, y_2), (x_3, y_3)$ is
$0 = \det \begin{pmatrix} x_1 & y_1 & 1 \\ x_2 & y_2 & 1 \\ x_3 & y_3 & 1 \end{pmatrix}$.
which has the form $ax^2+by^2+cx+dy+e=0$
for $a,d \in \mathbb{Q}$, rational. The center of this circle
is $(-\frac{d}{2a}, -\frac{c}{2b})$, which is again a rational point.
B-2 We claim that $E(x) = \ln(ax-1)n^2$, where $a = \frac{1}{n^2}$, where $a = \frac{1}{n^2}$. Indeed, temporarily $G(x) = \ln(x-ax) + \ln(x+ax) = \ln(x^2-a^2) = \ln(x^2-1/n^2)$. Indeed, $G(x) = \ln(x^2-1/n^2) = \ln((x-1/n)(x+1/n)) = \ln(x-1/n) + \ln(x+1/n)$.
and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim follows the Fundamental Theorem of Calculus and the claim