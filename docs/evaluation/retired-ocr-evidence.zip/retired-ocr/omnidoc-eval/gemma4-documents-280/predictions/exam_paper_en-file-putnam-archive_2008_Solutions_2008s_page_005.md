w1, ..., wn be the projections of e1, ..., en. If the desired
condition is not achieved, we can choose i such that
|w_i|^2 < |w_i|^2 + |w_i|^2 < |w_j|^2.
By choosing a suitable rotation that fixes
e_i for i, we can vary |w_i|, |w_j| without varying
|w_i|^2 + |w_j|^2 or |w_i|^2 + |w_j|^2. We can thus choose
such a rotation to force one of |w_i|^2, |w_j|^2 to become
equal to |w_i|^2 + |w_j|^2, |w_i|^2 + |w_j|^2. Repeating at most n - 1
times gives the desired configuration.
B-4 We use the identity given by Taylor's theorem:
h(x+y) = \sum_{i=0}^{n} \frac{d^i h(x)}{i!} y^i = \sum_{i=0}^{n} \frac{h^{(i)}(x)}{i!} y^i.
In this expression, h^{(i)}(x)/i is a polynomial in x with
integer coefficients, so it evaluates at an integer x as
an integer.
B-5 In all solutions, let $F_k$ be the number of $k$-limited per-
mutations of $\{1, \dots, n\}$.
First solution: (by Jacob Tsimerman) Note that any
permutation is $k$-limited if and only if its inverse is $k$-
limited. The number of $k$-limited permutations is $k! \binom{n}{k}$.
We use the following fact several times: the number of
involutions of $\{1, \dots, n\}$ is $\frac{1}{2} \binom{n}{2} + \frac{1}{2} = \frac{n(n-1)}{4} + \frac{1}{2}$.
We use the following fact that no two elements in a
pair come in pairs, so the number of involutions has the same
parity as the number of permutations, namely $n!$.
For $n \le k$, all $k$-limited involutions are $k$-limited. By the
previous paragraph, $F_k = \frac{1}{2} \binom{n}{k}$. By the
previous paragraph, $F_k = \frac{1}{2} \binom{n}{k}$.
For $n \ge k$, all $k$-limited involutions are $k$-limited. By the
previous paragraph, $F_k = \frac{1}{2} \binom{n}{k}$.
For $n \ge k$, all $k$-limited involutions are $k$-limited. By the
previous paragraph, $F_k = \frac{1}{2} \binom{n}{k}$.
For $n