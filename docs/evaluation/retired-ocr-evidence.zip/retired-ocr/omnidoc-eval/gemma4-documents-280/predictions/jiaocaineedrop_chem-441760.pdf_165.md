```html
<h1>FUNCTIONAL GROUPS IN ORGANIC CHEMISTRY</h1>
<img src="Organic-Functional-Groups-24re.pdf" alt="Organic-Functional-Groups-24re.pdf">
<p>Figure 5.2.1: Functional groups in organic chemistry. (CC BY-NC-ND, CompoundChem.)</p>
<p>This page titled 5.2: Families of Organic Molecules - Functional Groups is shared under a CC BY-NC-SA 3.0 license and was authored, remixed, and/or curated by Lisa Sharpe Elles.</p>
```