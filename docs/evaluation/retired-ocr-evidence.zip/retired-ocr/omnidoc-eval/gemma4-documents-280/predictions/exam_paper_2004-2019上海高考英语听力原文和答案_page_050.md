1. M: When will Flight BA981 from New York arrive?
W: It was scheduled to arrive at 1:00 p.m., but it will be delayed for an hour and a half.
M: Wait, will the plane arrive?
W: And will it?
M: I'd like to have a look at that blue sweater in the window.
Q: Yes, what size do you take?
M: No, thank you. I've already known what I want to order.
Q: What's the possible relationship between the two speakers?
M: Good evening, sir, would you like to see the menu?
M: No, thank you. I've already known what I want to order.
Q: What's the possible relationship between the two speakers?
M: Hotel rooms along the beach must be very expensive.
Q: What does the woman say about the hotel rooms now?
M: John, how did your math go?
M: I thought I might have failed but in fact I became the top 10% in the class.
Q: What can we learn about the man from the conversation?
W: What did you think of yesterday's film?
M: Well, I left the man only half way through.
Q: What was the film like according to the man?
W: Come on, what are we waiting for?
M: Sorry, Madam, I can't start until you put on your seat belt.
Q: What does the man mean?
W: I'm sorry, Madam, I can't start until you put on your seat belt.
Q: What does the woman mean?
M: Congratulations, Mary! I had you won the first prize at the speech contest.
W: There must be another Mary. I wasn't there.
Q: What does the woman react to the man's remark?
W: Oh, that's too bad. It's out of order again.
Q: What are the speakers probably talking about?
W: They gave me a seat on the 90th floor.
Part B Passages
Directions: In Part B, you will hear two short passages and you will be asked three questions on each of the passages. The passages will be read twice but the questions will be spoken only once. When you hear a question, read the four possible answers on your paper and decide which one would be the answer to the question you have heard.
Questions 11 through 13 are based on the following passage.
Last month, I went to Manchester for a work meeting. I booked a very nice hotel for two nights and I was very happy with it. My room was beautiful and the restaurant served very good food. In fact my dinner there first night was delicious, but when I came back from my meeting on the second day, I found my room empty. All my things had disappeared. I checked that I was in the right room and then I rushed to the reception. I was really worried because I thought I'd been robbed. When I got to the reception, I said my room was empty. All my things had been stolen but the