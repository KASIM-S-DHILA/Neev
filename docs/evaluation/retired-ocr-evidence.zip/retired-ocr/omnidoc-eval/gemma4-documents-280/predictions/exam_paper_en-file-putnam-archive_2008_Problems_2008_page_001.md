A1 Let $f: \mathbb{R} \to \mathbb{R}$ be a function such that $f(x, y) = f(x+y)$
$f(x) = 0$ for all real numbers $x, y$, and $x$. Prove that
there exists a function $g: \mathbb{R} \to \mathbb{R}$ such that $f(x, y) = g(x) - g(x+y)$ for all real numbers $x$ and $y$.

A2 Alan and Barbara play a game in which they take turn
filling entries of an initially empty $2008 \times 2008$ array.
Alan plays first. At each turn, a player chooses a real
number and places it in a vacant entry. The game ends
when all the entries are filled. Alan wins if the determin
ant of the resulting matrix is nonzero. Barbara wins if
it is zero. Which player has a winning strategy?

A3 Start with a finite sequence $a_1, a_2, \dots, a_n$ of positive
integers. If possible, choose two indices $i < j$ such that $a_i \neq a_j$.
If possible, choose two indices $i < j$ such that $a_i = a_j$ and $a_i \neq a_j$.
If possible, choose two indices $i < j$ such that $a_i = a_j$ and $a_i \neq a_j$.
Prove that if this process is repeated, it must eventually stop and the se-
quence does not stop. Prove that if the choices made. Note:
gcd means greatest common divisor and lcm means least common mulle.

A4 Define $f: \mathbb{R} \to \mathbb{R}$ by
$f(x) = \frac{x}{x^2}$ if $x \neq 0$
$f(x) = 0$ if $x = 0$

(The elements of $G$ in the sequence are not required to
be distinct. A subsequence of a sequence is obtained
by selecting some of the terms, not necessarily conse-
utive, without reordering them, for example, $4, 4, 2$ is a
subsequence of $4, 4, 2, 2, 4, 2, 1$.

B1 What is the maximum number of rational points that
can lie on a circle in $\mathbb{R}^2$?
(A rational point is a point of both coordinates are rational.)
Are rational numbers.

B2 Let $f(x) = \ln x$. For $x > 0$ and $x > 0$, let $f_n(x) = f_n(f_{n-1}(x))$.
$f_n(x) = \ln^n x$.

B3 What is the largest radius of a circle contained
in a 4-dimensional hypercube of side length $1$?

B4 Let $p$ be a prime number. Let $h(x)$ be a polynomial
with integer coefficients such that $h(0, 1), h(1, 0), h(1, 1), \dots, h(p-1, p-1)$
are distinct modulo $