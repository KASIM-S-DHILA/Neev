```html
<p>LibreTexts</p>
<p>C<sub>12</sub>H<sub>22</sub>O<sub>11</sub>(s) + heat → 12 C(s) + 11 H<sub>2</sub>O(g)</p>
<p>(5.1.2)</p>
<img src="[QR Code Image]" alt="QR Code">
<iframe src="[YouTube Video Embed]" width="400" height="225"></iframe>
<p>Video 5.1.2: A science experiment in the kitchen shows what happens to sugar molecules when they are heated. The experiment did not disappoint!</p>
<p>As with salt, sugar has radically different properties (both physical and chemical) than its constituent elements. This difference in properties, of constituent elements and compounds, is a central feature of chemical reactions.</p>
<p>Contributions & Attributions</p>
<ul>
<li><a href="[Wikipedia Link]">Wikipedia</a></li>
<li><a href="[Source Link]">5.1: Sugar and Salt</a> is shared under a CC BY-NC-SA 4.0 license and was authored, remixed, and/or curated by LibreTexts.</li>
<li><a href="[Source Link]">5.1: Sugar and Salt</a> by Henry Agnew, Marisa Alvar-Agnew is licensed CK-12. Original source: <a href="https://www.ck12.org/c/chemistry/...">https://www.ck12.org/c/chemistry/</a>.</li>
</ul>
<p>5.1.2</p>
<p><a href="https://chem.libretx.org/go/page/98005">https://chem.libretx.org/go/page/98005</a></p>
```