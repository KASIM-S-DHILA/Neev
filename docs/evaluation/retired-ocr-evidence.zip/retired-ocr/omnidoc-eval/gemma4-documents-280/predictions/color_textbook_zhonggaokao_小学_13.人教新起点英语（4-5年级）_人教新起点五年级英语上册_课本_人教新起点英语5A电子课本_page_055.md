Let's Check
A Listen and put the things into the right bag.
B Let's play.
Choose a picture and make a dialogue.

[Image of an airplane] [Image of a box] [Image of a green mat] [Image of a yellow airplane] [Image of a brown box]

[Image of a picture of a person] [Image of a picture of a person] [Image of a picture of a person]

52