```markdown
# 2020 Global Private Equity Survey

But are CFOs ready? Do they have the
requisite skills, tactical as well as technical,
to serve as a strategic leader in tomorrow's
private equity firm? As the industry
continues to mature and evolve and contend
with the forces of disruption, the CFO will
increasingly be looked upon to up his or her
game and become a leader for the firm. In
addition to technical skills, CFOs will
need to display the emotional intelligence
required to be effective strategic leaders, for
the people on their team as well as the entire
organization. That means they will need to
balance self-awareness with self-regulation
and empathy as they make the tough
decisions necessary to remain competitive
with other funds.

If you are planning to raise a fund in 2020,
will the fund be equal to, smaller than or larger
than your last fund raised?

| Year | Firms raising a larger fund | Firms raising a fund |
|---|---|---|
| 2016 | 45% | 53% |
| 2017 | 55% | 60% |
| 2018 | 55% | 60% |
| 2019 | 52% | 65% |
| 2020 | 58% | 76% |
```