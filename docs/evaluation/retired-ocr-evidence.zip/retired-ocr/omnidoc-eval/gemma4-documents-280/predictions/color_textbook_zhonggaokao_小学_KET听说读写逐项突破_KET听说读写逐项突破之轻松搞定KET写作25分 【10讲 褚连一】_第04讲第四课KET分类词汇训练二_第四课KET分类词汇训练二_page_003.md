| KET 分类词汇词条 | |
| :--- | :--- |
| painter | painter n. 高家 |
| photography | photography n. 摄影 |
| practise | practise/pratise n./v. 练习, 实践 |
| prize | prize n. 奖品 |
| programme | programme n. 节目 |
| project | Project n. 工程、项目 |
| website | website n. 网站 |
| present | present n. 礼物 |
| actor | actor n. 演员 |
| artist | artist n. 艺术家 |
| businessman | businessman n. 商人 |
| chemist | chemist n. 化学家, 厨师 |
| cleaner | cleaner n. 清洁工 |
| colleague | colleague n. 同事 |
| company | company n. 公司 |
| computer | computer n. 电脑 |
| customer | customer n. 顾客 |
| dentist | dentist n. 牙医 |
| diploma | diploma n. 文凭 |
| doctor | doctor n. 医生 |
| driver | driver n. 司机 |
| earn | earn v. 赚得, 获得 |
| engineer | engineer n. 工程师 |
| guest | guest n. 客人 |
| guide | guide n. 指南 |
| hairdresser | hairdresser n. 理发师 |
| instructions | instructions n. 说明书 |
| nurse | nurse n. 护士 |
| occupation | occupation n. 职业 |
| pharmacy | pharmacy n. 药房 |
| photographer | photographer n. 摄影师 |
| receptionist | receptionist n. 接待员 |
| secretary | secretary n. 秘书 |
| shop assistant | shop assistant n. 店员 |
| staff | staff n. 全体人员, 同事 |
| uniform | uniform n. 制服 |
| accident | accident n. 事故, 意外 |
| appointment | appointment n. 预约, 预约 |
| arm | arm n. 手臂 |
| body | body n. 身体 |
| back | back n. 后, 背骨 |
| check | check n. 检查 |
| dangerous | dangerous a. 危险的 |
| dentist | dentist n. 牙医 |