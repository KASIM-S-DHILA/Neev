```markdown
LibreTexts®

$\Delta_{\text{O}}$ (Weak Field) $\quad \Delta_{\text{O}}$ (Strong Field)

Figure 7: The difference between d-orbitals in metal ions is $\Delta_{\text{O}}$ which influences their electron spin. If $\Delta_{\text{O}}$ is small, then it requires less energy for the electrons to move up into a higher energy orbital than it does to pair up, but when $\Delta_{\text{O}}$ is large, the jump into the next orbital would be too high. Note that this only impacts $d_{z^2}$-electrons.

Some of the factors that contribute to $\Delta_{\text{O}}$ include the formal charge of the ion, the location of the ion on the periodic table, and the types of ligands in the system. All of the donor atoms in the binding site of lactoferrin (except histidine) are sigma and pi donors. Sigma and pi donors are typically involved in weak field interactions, which is a smaller distance between d-orbitals ($\Delta_{\text{O}}$). In addition, iron (III) has a location in the fourth row of the periodic table, and $\Delta_{\text{O}}$ decreases going up the periodic table. These factors indicate that iron (III) in lactoferrin has a weak field. Since iron (III) is a $d^5$ electron, a weak field means that iron's $d$-electrons will occupy the higher energy orbitals, and won't pair up.

Ligand field stabilization energy (LFSE) can suggest the preferred geometry of an ion. The LFSE is calculated using the equation
$$\text{LFSE} = -0.4 \times \Delta_{\text{O}} + 0.6 \times \text{number of electrons in lower energy orbitals, and } \gamma \text{ is equal to the number of electrons in higher energy orbitals. Iron (III) has a LFSE of zero, which means there is no other ligand position that would provide a lower LFSE, and so iron is able to form stable bonds in geometry configuration. Usually $d^5$ metal ions form an octahedral complex when bound to six ligands (see figure 8). However, in the case of lactoferrin, the carbonate ion causes a slight change in the geometry which results in a distorted octahedral configuration.

10.3.6
https://chem.libretx.org/go/page/436352
```