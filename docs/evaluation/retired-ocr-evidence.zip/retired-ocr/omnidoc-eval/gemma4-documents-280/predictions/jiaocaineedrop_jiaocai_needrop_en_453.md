```html
<table>
<thead>
<tr>
<th>Page Number</th>
<th>Text</th>
</tr>
</thead>
<tbody>
<tr>
<td>25.</td>
<td>www.jinhua.com "在线名师" 资料 免费资料 任何下载</td>
</tr>
<tr>
<td></td>
<td>www.jinhua.com</td>
</tr>
<tr>
<td></td>
<td>5. --- won the first place in the "Super Girl" singing competition?</td>
</tr>
<tr>
<td></td>
<td>A. Who</td>
<td>B. When</td>
<td>C. Where</td>
<td>D. Why</td>
</tr>
<tr>
<td></td>
<td>26. Shops in big cities are</td>
<td>A. expensive</td>
<td>B. expensive</td>
<td>C. most expensive</td>
<td>D. the most expensive</td>
</tr>
<tr>
<td></td>
<td>27. You</td>
<td>A. play football in the street. It's too dangerous.</td>
<td>B. needn't</td>
<td>C. mustn't</td>
<td>D. couldn't</td>
</tr>
<tr>
<td></td>
<td>28. It's snowing now. You'd better</td>
<td>A. drive</td>
<td>B. drive</td>
<td>C. driving</td>
<td>D. to drive</td>
</tr>
<tr>
<td></td>
<td>29. My little brother asks me</td>
<td>A. tell</td>
<td>B. told</td>
<td>C. telling</td>
<td>D. to tell</td>
</tr>
<tr>
<td></td>
<td>30. Today, more and more people enjoy</td>
<td>A. buy</td>
<td>B. bought</td>
<td>C. buying</td>
<td>D. to buy</td>
</tr>
<tr>
<td></td>
<td>31. Don't turn on the radio. Grandpa</td>
<td>A. sleeps</td>
<td>B. is sleeping</td>
<td>C. has slept</td>
<td>D. slept</td>
</tr>
<tr>
<td></td>
<td>32. Have you ever seen the cartoon Tom and Jerry?</td>
<td>A. Yes</td>
<td>B. it</td>
<td>C. many times</td>
<td>D. have seen</td>
</tr>
<tr>
<td></td>
<td>33. --- The pizza</td>
<td>A. see</td>
<td>B. saw</td>
<td>C. will see</td>
<td>D. have seen</td>
</tr>
<tr>
<td></td>
<td>34. --- Yes, please.</td>
<td>A. was made</td>
<td>B. made</td>
<td>C. is made</td>
<td>D. makes</td>
</tr>
<tr>
<td></td>
<td>35. --- Could you please tell us</td>
<td>A. was</td>
<td>B. the</td>
<td>C. the</td>
<td>D. Is that