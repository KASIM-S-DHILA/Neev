```markdown
LibreTexts
NOT outline. Think about how you want to organize your essay. Are all issues treated equally? What is your plan to address all issues?
A good way to outline is to organize your facts as we discussed above. For example, think back to that table:
Rule Element Facts
Motor scooters have an engine and can move without "manpower"
No running on rails
Runs over land
Can move with only manpower, meaning the rider can use their feet to get to it
Which is the predominant use?
Not on a motor scooter
Can also move with only manpower, meaning the rider can use their feet to get to it
Which is the predominant use?
No rails on a motor scooter
Can't fly
You might notice that there isn't much to talk about with "runs over land." I mean, a motorized scooter certainly doesn't fly in the air, so this feels obvious. But "self-propelled" seems to have to more to discuss! So that means you will likely want to spend more time on the issue of whether a motor scooter is self-propelled than it runs over land.
If there are multiple issues, you can also use this type of chart to determine which issues require the most time.
Speaking of issues, outlining will help you issue spot. You will hear this as a buzzword all around: that you need to "spot the issue" or "issue spot." But what does that mean? Remember that a hypothetical is a story. So your job is to read the story and determine the issues or questions to solve. A professor may ask you a very directed question, such as "Did Defendant commit murder?" in which case, your issue-spot is just gosh much easier! However, if that make the plaintiff the poor and the hypothetical story with "What are the rights of the parties?" or "What crimes can Bob be charged with?"
This means that a large part of assigning points on your exam is figuring out what issues, or legal problems, to solve. Everyone tackles this in a slightly different way. However, is suggesting one of the two things described below and making it your own.
Issue Spotting Method 1: The Checklist
In doing the outlining that I mentioned above, you can create a mini-outline or attack outline, which is what I just call a checklist. Essentially, it should be a one-page list of the types of law you covered. For example, in a torts class, you are going to cover various types of torts. Therefore, your checklist might look something like this:
1. Intentional Torts
a. Assault
b. Battery
c. False Imprisonment
d. Trespass
e. Trespass to Chattels
f. Conversion
2. Negligence
Note that is an incomplete checklist, and the complete version will look different depending on your professor and class. The idea is that if I have memorized, I can quickly go through the fact pattern to see if any of the torts show up. Part of your checklist might also be to add in "activating facts." What I mean by that is, if you are looking for an assault, a battery, or a battery, for battery, I might know that I need a person in the fact pattern to touch another person, so I'm indicating that in my checklist. I can go through the story and think, "Alright, is anyone touching someone else? If so, could that be a battery?" Similarly, trespass requires land or entering the land of another. Is that showing up in the facts? Adding these types of "activating facts" to your checklist might look like this:
1. Intentional Torts
a. Assault
```