System of linear equations

A collection of one or more equations involving the same variables. Example:
The system of linear equations $\{2x_1 + 3x_2 + 4x_3 = 5, 5x_3 + 6x_4 = 7\}$ can be rewritten as
$2x_1 + 3x_2 + 4x_3 + 0x_4 = 5$
$0x_1 + 0x_2 + 5x_3 + 6x_4 = 7$
Hence it is a system of equations involving the variables $x_1, x_2, x_3, x_4$.