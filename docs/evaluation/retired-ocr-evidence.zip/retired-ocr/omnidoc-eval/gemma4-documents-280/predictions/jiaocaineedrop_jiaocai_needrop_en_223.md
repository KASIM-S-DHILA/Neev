```markdown
# 精华学校
www.jinhua.com “在给我都” 答庭室 随时随地同友

48. “Augie is Jenny’s bridge to the world” means that
A. It helps Jenny a lot in her life
B. It does everything if can for Jenny
C. It picks up things Jenny drops at school
D. children who don’t know Jenny come to talk to her because of Augie

B
This is a chart of a car’s fuel consumption during a certain day.

| Time of day | Amount of petrol (l) |
|---|---|
| 7am | 5 |
| 8am | 10 |
| 9am | 20 |
| 10am | 35 |
| 11am | 40 |
| 12pm | 35 |
| 1pm | 25 |
| 2pm | 15 |
| 3pm | 10 |
| 4pm | 5 |
| 5pm | 5 |
| 6pm | 5 |

49. The above chart shows
A. How much petrol was needed to fill the tank
B. The speed the car was going
C. Which trip used the most petrol
D. How far the car travelled

50. The driver bought petrol at
A. 8 a.m.
B. 9 a.m.
C. 4 p.m.
D. 6 p.m.

51. Throughout the day the car used
A. 45 litres of petrol
B. 40 litres of petrol
C. 35 litres of petrol
D. 10 litres of petrol

There are many unusual hotels around the world. In Greenland, there is a hotel made out of ice, open between December and April every year. In Turkey, there is a cave hotel with a television, furniture, and a bathroom in each room. And in Bolivia, there is the Salt Palace Hotel.

Thousands of years ago, the area around the Salt Palace Hotel was a large lake. But over time, all the water disappeared. Today, the area has only two small lakes and two salt deserts. The larger of the two deserts, the Uyuni Salt desert, is 12,000 square kilometres. During the day, the desert is bright white because of the salt. There are no roads across the Uyuni desert, so local people must go the way to the hotel.

In the early 1990s, a man named Juan Quesada built the hotel. He cut big blocks of sand from the desert and used the blocks to build it. Everything in the hotel is made out of salt: the walls, the roof(屋顶), the tables, the chairs, the beds, and the hotel’s bar.

-