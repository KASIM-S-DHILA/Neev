| | |
|---|---|
| **Verizon** | 12:14 PM |
| | 95% |
| | 12:12 PM |
| | 94% |
| **Notes** | **Done** |
| October 1, 2013, 12:14 PM | October 1, 2013, 12:11 PM |
| He was new to China. In fact, his first words were, " | He was new to China. In fact, his first words were, "上顶级 |
| English (US) | 简体手写 |
| | **JIO** |
| | **JOP** |
| | **Català** |
| | **J K L** |
| | **Français (Canada)** |
| | **NM** |
| | **Emoji** |
| | **space** |
| | **return** |
| | **下页** |
| | **确认** |
| it.) Each time you tap it, you rotate to the next keyboard you requested earlier. The new language's name appears briefly on the space bar to identify it. | |
| Thanks to ⌘ button, you can freely mix languages and alphabets within the same document without having to duck to some control panel to make the change. And thanks to the iPhone's virtual keyboard, the actual letters on the keys" change in real time. | |
| The ⌘ button works in three ways: | |
| Tap it once to restore the most recent keyboard. Great if you're frequently flipping back and forth between two languages. | |
| Tap it rapidly to cycle among all the keyboards you've selected. (The name of the language appears briefly on the space bar to help you out.) | |
| If you, some United Nations translator, like to write in a lot of different languages, you don't have to tap ⌘ key over and over again to cycle through the keyboard layouts. Instead, hold your finger down | |
| Typing, Editing & Searching | 85 |