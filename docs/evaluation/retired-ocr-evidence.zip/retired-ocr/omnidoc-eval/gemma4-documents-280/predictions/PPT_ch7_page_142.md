SUMMARY OF CHAPTER 7
Linear Algebra: Matrices, Vectors, Determinants. Linear Systems
(continued 3)
The transpose $A^T$ of a matrix $A = [a_{ij}]$ is $A^T = [a_{jk}]$; rows become columns and conversely (Sec. 7.2). Here, $A$ need not be square. If it is and $A = A^T$, then $A$ is called symmetric; if $A = -A^T$, it is called skew-symmetric. For a product, $(AB)^T = B^T A^T$ (Sec. 7.2).
A main application of matrices concerns linear systems of equations
(2) $Ax = b$ (Sec. 7.3)
$(m$ equations in $n$ unknowns $x_1, \ldots, x_n$, $A$ and $b$ given).
Section 7.Summary p142
Advanced Engineering Mathematics, 10/e by Edwin Kreyszig
Copyright 2011 by John Wiley & Sons. All rights reserved.