Solutions to the 60th William Lowell Putnam Mathematical Competition
Saturday, December 4, 1999

A-1 Note that if $r(x)$ and $s(x)$ are any two functions, then
$$a_n(x) = r(x) + s(x) \quad \text{and} \quad a_{n+1}(x) = a_n(x) + a_{n+1}(x)$$
Therefore, if $f(x)$ is the given function, we have
$$F(x) = \max(-3x - 3, 0) + \max(5x, 0) + 3x + 2$$
$$= (-3x - 3) + \max(5x, 0) + 3x + 2$$
$$= (-3x - 3) + 5x + 3x + 2$$
$$= 5x - 1$$
$$= (3x + 3) - 5x + 2$$
$$= 2$$
so we may set $f(x) = (3x + 3) - 5x + 2$, $g(x) = 5x/2$, and $h(x) = -x + 3$.

A-2 First Solution: First factor $p(x) = q(x)r(x)$, where $q$ has all real roots and $r$ has all complex roots. Notice that each root of $q$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r$ has all complex roots. Notice that each root of $r